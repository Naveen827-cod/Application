#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT HUP INT TERM
mkdir -p "$WORK/classes"
find "$ROOT/app/src/main/java/com/naveenrx100/tool/npak" -name '*.java' -print > "$WORK/sources.txt"
javac -source 8 -target 8 -d "$WORK/classes" @"$WORK/sources.txt"
cat > "$WORK/NpakTestRunner.java" <<'JAVA'
import com.naveenrx100.tool.npak.PakRepackSelfTest;
public final class NpakTestRunner {
    public static void main(String[] args) {
        PakRepackSelfTest.Result result = PakRepackSelfTest.run(null);
        System.out.print(result.report);
        if (!result.passed) System.exit(1);
    }
}
JAVA
javac -source 8 -target 8 -cp "$WORK/classes" -d "$WORK/classes" "$WORK/NpakTestRunner.java"
java -cp "$WORK/classes" NpakTestRunner
