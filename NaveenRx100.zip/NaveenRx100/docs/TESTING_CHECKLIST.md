# Testing Checklist

**EDUCATIONAL PURPOSE ONLY. Test only synthetic NPAK files and standard Lua samples you own.**

## Platform-independent NPAK tests

Run `sh tools/run-synthetic-tests.sh`.

- [ ] Synthetic archive builds with two entries.
- [ ] Index/footer parses and hashes validate.
- [ ] Repacking with no edits preserves the index hash.
- [ ] 8 MiB unencrypted payload extracts byte-for-byte.
- [ ] Repack replaces a file and adds a new file.
- [ ] AES-GCM encrypted files, including an 8 MiB payload, can be injected and extracted with the right key.
- [ ] Encrypted extraction without a key fails safely.
- [ ] AES-GCM tag/authentication failure does not publish a final extracted file.
- [ ] `../` path traversal is rejected.
- [ ] Cancellation stops an archive operation.
- [ ] Corrupt footer/index hash is rejected.

## Android manual tests (not run in this environment)

- [ ] Open a synthetic `.npak` through Android's document picker.
- [ ] Verify viewer lists the correct entry count, paths, and sizes.
- [ ] Extract to a user-selected folder and compare output hashes.
- [ ] Repack an edited folder and reopen the output.
- [ ] Build a new archive from a selected folder and a valid NPAK template.
- [ ] Add one file with a relative archive path.
- [ ] Cancel a long operation and confirm an existing output remains unchanged.
- [ ] Open/edit/save a UTF-8 `.lua` source file.
- [ ] Verify compiler/decompiler missing-backend messages are honest.
- [ ] Test on API 24 and a current Android release.
- [ ] Check rotation/backgrounding and low-storage behavior.

## Full build status

A full Gradle/Android SDK build and emulator/device run were not available in the review environment. Do not mark the Android manual tests complete until they have actually been run.
