# Android Studio Build Guide

**EDUCATIONAL PURPOSE ONLY.**

## Requirements

- Android Studio with Android SDK Platform 35 installed.
- JDK 17 selected for Gradle.
- Android Gradle Plugin 8.6.1 and Gradle 8.7.
- Internet access on the first build to resolve Gradle and Maven dependencies.

## Wrapper note

This source package includes `gradle/wrapper/gradle-wrapper.properties`, but not the official `gradle-wrapper.jar`: the review environment had no network access and no Gradle installation from which to generate it. The provided `gradlew` script will use a locally installed Gradle if available and otherwise prints a clear setup message.

To generate the standard wrapper files using an installed Gradle 8.7:

```sh
gradle wrapper --gradle-version 8.7 --distribution-type bin
```

This should create `gradle/wrapper/gradle-wrapper.jar` and replace the launcher scripts with the official wrapper scripts. Then run:

```sh
./gradlew --version
./gradlew :app:assembleDebug
```

On Windows:

```bat
gradlew.bat --version
gradlew.bat :app:assembleDebug
```

Alternatively, open the project root in Android Studio, set Gradle JDK to JDK 17, install SDK Platform 35 in SDK Manager, and sync after generating the wrapper files.

## APK location

After a successful debug build, Android Gradle Plugin normally writes the APK to:

`app/build/outputs/apk/debug/app-debug.apk`

No APK is included in this source ZIP because a full Android build was not possible in the offline review environment.

## Build troubleshooting

- `SDK location not found`: install SDK Platform 35 and configure `local.properties` locally; do not commit machine-specific `local.properties`.
- `Unsupported class file major version`: select JDK 17 for Gradle.
- Dependency resolution failures: check network access and Maven repository access.
- Missing Gradle wrapper JAR: run the wrapper-generation command above using Gradle 8.7.
- Lua compilation/decompilation errors: verify the optional compiler/decompiler backend is compatible; those tools are not bundled.
