/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool;

import android.app.Application;
import android.util.Log;
import com.naveenrx100.tool.core.Logger;

/** Application entry point for app-wide initialization. */
public final class MainApplication extends Application {
    private static final String TAG = "NaveenRx100";

    @Override
    public void onCreate() {
        super.onCreate();
        Logger.init(this);
        Log.i(TAG, "NaveenRx100 Tool initialized");
    }
}
