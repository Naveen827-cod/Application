/*
 * NaveenRx100 Tool - Generic InjectItem
 * EDUCATIONAL PURPOSE ONLY. Represents an item added to a synthetic archive.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;
import java.io.File;
public final class InjectItem {
    public final String internalPath; public final File sourceFile; public final byte[] encryptionKey;
    public InjectItem(String internalPath,File sourceFile){this(internalPath,sourceFile,null);}
    public InjectItem(String internalPath,File sourceFile,byte[] key){this.internalPath=PakIndexWriter.normalizePath(internalPath);if(sourceFile==null||!sourceFile.isFile())throw new IllegalArgumentException("Source file does not exist");this.sourceFile=sourceFile;if(key!=null)PakEncryptor.validateKey(key);this.encryptionKey=key==null?null:key.clone();}
    public boolean encrypted(){return encryptionKey!=null;}
}
