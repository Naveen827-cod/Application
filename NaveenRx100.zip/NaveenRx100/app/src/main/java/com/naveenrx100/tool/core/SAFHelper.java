/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Storage Access Framework helpers compatible with Android 7.0+ and scoped storage. */
public final class SAFHelper {
    public static final int REQUEST_OPEN_READ = 6101;
    public static final int REQUEST_OPEN_WRITE = 6102;
    public static final int REQUEST_OPEN_DIRECTORY = 6103;
    private SAFHelper() {}

    public static void openFileForRead(Activity activity, String mimeType) {
        try {
            if (activity == null) return;
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mimeType == null || mimeType.trim().isEmpty() ? "*/*" : mimeType);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            activity.startActivityForResult(intent, REQUEST_OPEN_READ);
        } catch (Exception e) { showError(activity, "Could not open file picker", e); }
    }

    public static void openFileForWrite(Activity activity, String suggestedName, String mimeType) {
        try {
            if (activity == null) return;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mimeType == null || mimeType.trim().isEmpty() ? "application/octet-stream" : mimeType);
            if (suggestedName != null && !suggestedName.trim().isEmpty()) intent.putExtra(Intent.EXTRA_TITLE, suggestedName);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            activity.startActivityForResult(intent, REQUEST_OPEN_WRITE);
        } catch (Exception e) { showError(activity, "Could not open save picker", e); }
    }

    public static void openDirectory(Activity activity) {
        try {
            if (activity == null) return;
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            activity.startActivityForResult(intent, REQUEST_OPEN_DIRECTORY);
        } catch (Exception e) { showError(activity, "Could not open folder picker", e); }
    }

    public static byte[] readBytesFromUri(Context context, Uri uri) {
        if (context == null || uri == null) return new byte[0];
        try {
            ContentResolver resolver = context.getContentResolver();
            try (InputStream input = resolver.openInputStream(uri);
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                if (input == null) throw new IllegalStateException("Provider returned no input stream");
                byte[] buffer = new byte[8192];
                int n;
                while ((n = input.read(buffer)) != -1) output.write(buffer, 0, n);
                return output.toByteArray();
            }
        } catch (Exception e) {
            Logger.error("SAF read failed for " + uri, e);
            return new byte[0];
        }
    }

    public static boolean writeBytesToUri(Context context, Uri uri, byte[] bytes) {
        if (context == null || uri == null || bytes == null) return false;
        try {
            ContentResolver resolver = context.getContentResolver();
            try (OutputStream output = resolver.openOutputStream(uri, "wt")) {
                if (output == null) throw new IllegalStateException("Provider returned no output stream");
                output.write(bytes);
                output.flush();
                return true;
            }
        } catch (Exception e) {
            Logger.error("SAF write failed for " + uri, e);
            return false;
        }
    }

    public static String getFileName(Context context, Uri uri) {
        if (context == null || uri == null) return "unknown";
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && !name.trim().isEmpty()) return name;
                }
            }
        } catch (Exception e) { Logger.warn("Could not query display name: " + e.getMessage()); }
        finally { if (cursor != null) try { cursor.close(); } catch (Exception ignored) { } }
        String last = uri.getLastPathSegment();
        return last == null ? "unknown" : last;
    }

    public static long getFileSize(Context context, Uri uri) {
        if (context == null || uri == null) return -1L;
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index);
            }
        } catch (Exception e) { Logger.warn("Could not query file size: " + e.getMessage()); }
        finally { if (cursor != null) try { cursor.close(); } catch (Exception ignored) { } }
        return -1L;
    }

    public static File copyUriToCache(Context context, Uri uri) {
        if (context == null || uri == null) return null;
        File out = null;
        try {
            File dir = new File(context.getCacheDir(), "saf_imports");
            if (!dir.exists() && !dir.mkdirs() && !dir.isDirectory()) throw new IllegalStateException("Cannot create cache directory");
            String safeName = FileHelper.sanitizeFilename(getFileName(context, uri));
            out = File.createTempFile("import_", "_" + safeName, dir);
            try (InputStream input = context.getContentResolver().openInputStream(uri);
                 FileOutputStream output = new FileOutputStream(out)) {
                if (input == null) throw new IllegalStateException("Provider returned no input stream");
                byte[] buffer = new byte[8192];
                int n;
                while ((n = input.read(buffer)) != -1) output.write(buffer, 0, n);
                output.flush();
            }
            return out;
        } catch (Exception e) {
            Logger.error("Could not copy URI into cache", e);
            if (out != null && out.exists()) try { out.delete(); } catch (Exception ignored) { }
            return null;
        }
    }

    /** Takes persistable access when the picker grants it; harmless if provider does not support it. */
    public static boolean persistPermission(Context context, Intent resultIntent, Uri uri, boolean write) {
        if (context == null || resultIntent == null || uri == null) return false;
        try {
            int granted = resultIntent.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            int wanted = write ? Intent.FLAG_GRANT_WRITE_URI_PERMISSION : Intent.FLAG_GRANT_READ_URI_PERMISSION;
            if ((granted & wanted) == 0) return false;
            context.getContentResolver().takePersistableUriPermission(uri, granted);
            return true;
        } catch (Exception e) {
            Logger.warn("Persistable permission unavailable: " + e.getMessage());
            return false;
        }
    }

    public static boolean hasUriAccess(Context context, Uri uri, boolean write) {
        if (context == null || uri == null) return false;
        try {
            int wanted = write ? Intent.FLAG_GRANT_WRITE_URI_PERMISSION : Intent.FLAG_GRANT_READ_URI_PERMISSION;
            for (android.content.UriPermission permission : context.getContentResolver().getPersistedUriPermissions()) {
                if (uri.equals(permission.getUri()) && (write ? permission.isWritePermission() : permission.isReadPermission())) return true;
            }
            return false;
        } catch (Exception e) {
            Logger.warn("URI permission check failed: " + e.getMessage());
            return false;
        }
    }

    private static void showError(Context context, String prefix, Exception e) {
        Logger.error(prefix, e);
        if (context != null) try {
            Toast.makeText(context, prefix + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
        } catch (Exception ignored) { }
    }
}
