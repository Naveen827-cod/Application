/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import com.naveenrx100.tool.R;

/** Centralized, explicit activity navigation for the app. */
public final class NavHelper {
    private NavHelper() {}

    public static void go(Activity from, Class<? extends Activity> target) {
        if (from == null || target == null) return;
        if (from.getClass().equals(target)) return;
        Intent intent = new Intent(from, target);
        from.startActivity(intent);
        from.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public static void bindToolbar(Activity activity, String title, String icon) {
        TextView titleView = activity.findViewById(R.id.toolbarTitle);
        TextView iconView = activity.findViewById(R.id.toolbarIcon);
        View back = activity.findViewById(R.id.toolbarBack);
        View settings = activity.findViewById(R.id.toolbarSettings);
        if (titleView != null) titleView.setText(title);
        if (iconView != null) iconView.setText(icon);
        if (back != null) back.setOnClickListener(v -> activity.finish());
        if (settings != null) settings.setOnClickListener(v -> go(activity, SettingsActivity.class));
    }

    public static void bindBottomNav(Activity activity) {
        bind(activity, R.id.navHome, HomeActivity.class);
        bind(activity, R.id.navLua, LuaToolsActivity.class);
        bind(activity, R.id.navPak, PakToolsActivity.class);
        bind(activity, R.id.navInject, InjectActivity.class);
        bind(activity, R.id.navProfile, ProfileActivity.class);
    }

    private static void bind(Activity activity, int id, Class<? extends Activity> target) {
        View view = activity.findViewById(id);
        if (view != null) view.setOnClickListener(v -> go(activity, target));
    }
}
