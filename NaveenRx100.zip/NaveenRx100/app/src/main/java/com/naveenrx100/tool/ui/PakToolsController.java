/*
 * NaveenRx100 Tool - Generic PakToolsController
 * EDUCATIONAL PURPOSE ONLY. Coordinates NPAK v1 operations for Android screens.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import com.naveenrx100.tool.npak.InjectItem;
import com.naveenrx100.tool.npak.PakOperations;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Small UI-neutral facade so activities can share the same operation API. */
public final class PakToolsController {
    private final AtomicBoolean cancelled=new AtomicBoolean(false);
    public void cancel(){cancelled.set(true);}
    public void resetCancellation(){cancelled.set(false);}
    public int extract(File input,File output,PakOperations.Callback callback)throws IOException{return PakOperations.extractAll(input,output,null,callback,cancelled);}
    public int repack(File input,File edits,File output,boolean forceAdd,PakOperations.Callback callback)throws IOException{return PakOperations.repack(input,edits,output,forceAdd,callback,cancelled);}
    public int build(File template,File edits,File output,PakOperations.Callback callback)throws IOException{return PakOperations.buildNew(template,edits,output,callback,cancelled);}
    public int inject(File input,List<InjectItem> plan,File output,PakOperations.Callback callback)throws IOException{return PakOperations.inject(input,plan,output,callback,cancelled);}
}
