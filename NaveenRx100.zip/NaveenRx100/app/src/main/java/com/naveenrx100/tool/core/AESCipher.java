/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.security.GeneralSecurityException;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** AES-CBC helpers. Java PKCS5Padding uses the same block padding bytes as PKCS#7 for AES. */
public final class AESCipher {
    private AESCipher() {}
    private static void validate(byte[] key, byte[] iv, byte[] input) {
        if (key == null || !(key.length == 16 || key.length == 24 || key.length == 32))
            throw new IllegalArgumentException("AES key must be 16, 24, or 32 bytes");
        if (iv == null || iv.length != 16) throw new IllegalArgumentException("AES-CBC IV must be 16 bytes");
        if (input == null) throw new IllegalArgumentException("ciphertext must not be null");
        if ((input.length & 15) != 0) throw new IllegalArgumentException("AES-CBC ciphertext length must be a multiple of 16");
    }
    /** Strict CBC decrypt with PKCS#7/PKCS5 padding validation. */
    public static byte[] decrypt(byte[] ciphertext, byte[] key, byte[] iv) throws GeneralSecurityException {
        validate(key, iv, ciphertext);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        return cipher.doFinal(ciphertext);
    }
    /** CBC decrypt without padding processing, useful for formats that tolerate invalid padding. */
    public static byte[] decryptNoPadding(byte[] ciphertext, byte[] key, byte[] iv) throws GeneralSecurityException {
        validate(key, iv, ciphertext);
        Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        return cipher.doFinal(ciphertext);
    }
    /** Removes valid PKCS#7 padding, otherwise returns the raw decrypted bytes. */
    public static byte[] decryptPkcs7OrRaw(byte[] ciphertext, byte[] key, byte[] iv) throws GeneralSecurityException {
        byte[] raw = decryptNoPadding(ciphertext, key, iv);
        int n = raw.length;
        if (n == 0) return raw;
        int pad = raw[n - 1] & 0xFF;
        if (pad < 1 || pad > 16 || pad > n) return raw;
        int diff = 0;
        for (int i = n - pad; i < n; i++) diff |= (raw[i] & 0xFF) ^ pad;
        return diff == 0 ? Arrays.copyOf(raw, n - pad) : raw;
    }
    public static byte[] decrypt_cbc(byte[] ciphertext, byte[] key, byte[] iv) throws GeneralSecurityException { return decrypt(ciphertext, key, iv); }
}
