/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class Logger {
    public static final String TAG = "NaveenRx100";
    private static final int MAX_LINES = 500;
    private static final ArrayDeque<String> BUFFER = new ArrayDeque<>();
    private static Context appContext;
    private static final Object LOCK = new Object();

    private Logger() {}

    public static void init(Context context) {
        if (context != null) appContext = context.getApplicationContext();
    }

    public static void log(String message) { append("INFO", message, null); Log.i(TAG, safe(message)); }
    public static void warn(String message) { append("WARN", message, null); Log.w(TAG, safe(message)); }
    public static void error(String message) { append("ERROR", message, null); Log.e(TAG, safe(message)); }
    public static void error(String message, Throwable throwable) {
        append("ERROR", message, throwable);
        Log.e(TAG, safe(message), throwable);
    }

    private static String safe(String value) { return value == null ? "null" : value; }

    private static void append(String level, String message, Throwable throwable) {
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = time + " [" + level + "] " + safe(message);
        if (throwable != null) line += " (" + throwable.getClass().getSimpleName() + ": " + safe(throwable.getMessage()) + ")";
        synchronized (LOCK) {
            BUFFER.addLast(line);
            while (BUFFER.size() > MAX_LINES) BUFFER.removeFirst();
        }
    }

    public static List<String> getRecentLogs() {
        synchronized (LOCK) { return new ArrayList<>(BUFFER); }
    }

    public static File saveLogToFile() throws IOException {
        Context context = appContext;
        if (context == null) throw new IOException("Logger.init(context) must be called before saving logs");
        File directory = new File(context.getFilesDir(), "logs");
        FileHelper.ensureDir(directory);
        File file = new File(directory, "naveenrx100-" +
                new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) + ".log");
        try (FileWriter writer = new FileWriter(file, false)) {
            for (String line : getRecentLogs()) {
                writer.write(line);
                writer.write(System.lineSeparator());
            }
            writer.flush();
        }
        return file;
    }

    public static boolean saveLogToFile(File file) {
        if (file == null) return false;
        try {
            File parent = file.getAbsoluteFile().getParentFile();
            if (parent != null) FileHelper.ensureDir(parent);
            try (FileWriter writer = new FileWriter(file, false)) {
                for (String line : getRecentLogs()) {
                    writer.write(line);
                    writer.write(System.lineSeparator());
                }
            }
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Could not save log file", e);
            return false;
        }
    }
}
