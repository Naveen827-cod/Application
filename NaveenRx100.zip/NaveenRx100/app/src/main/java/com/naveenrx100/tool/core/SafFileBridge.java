/*
 * NaveenRx100 Tool - SafFileBridge
 * EDUCATIONAL PURPOSE ONLY. Demonstrates Android Storage Access Framework file handling.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import androidx.documentfile.provider.DocumentFile;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Streaming bridge between SAF documents and app-private working files. */
public final class SafFileBridge {
    private static final int BUFFER=64*1024;
    private static final int MAX_TEXT_BYTES=16*1024*1024;
    public interface CancelCheck { boolean isCancelled(); }
    private SafFileBridge(){}
    public static File copyUriToCache(Context context,Uri uri,String prefix)throws IOException { return copyUriToCache(context,uri,prefix,null); }
    public static File copyUriToCache(Context context,Uri uri,String prefix,CancelCheck cancel)throws IOException {
        if(context==null||uri==null)throw new IOException("A document must be selected");File temp=File.createTempFile(prefix==null?"selected-":prefix,".bin",context.getCacheDir());boolean ok=false;
        InputStream raw=context.getContentResolver().openInputStream(uri);if(raw==null){temp.delete();throw new IOException("Cannot open selected document");}
        try(InputStream in=new BufferedInputStream(raw);FileOutputStream out=new FileOutputStream(temp)) {copy(in,out,cancel);out.getFD().sync();ok=true;return temp;}finally{if(!ok)temp.delete();}
    }
    public static void copyFileToUri(Context context,File source,Uri target)throws IOException { copyFileToUri(context,source,target,null); }
    public static void copyFileToUri(Context context,File source,Uri target,CancelCheck cancel)throws IOException {
        if(context==null||source==null||!source.isFile()||target==null)throw new IOException("Source or destination is invalid");ContentResolver resolver=context.getContentResolver();
        try(InputStream in=new BufferedInputStream(new FileInputStream(source));OutputStream out=new BufferedOutputStream(resolver.openOutputStream(target,"wt"))) {if(out==null)throw new IOException("Cannot open destination document");copy(in,out,cancel);out.flush();}
    }
    public static String readText(Context context,Uri uri)throws IOException {
        InputStream raw=context.getContentResolver().openInputStream(uri);if(raw==null)throw new IOException("Cannot open selected document");
        try(InputStream in=new BufferedInputStream(raw);ByteArrayOutputStream out=new ByteArrayOutputStream()) {byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>MAX_TEXT_BYTES)throw new IOException("Text file exceeds 16 MiB limit");out.write(b,0,n);}return out.toString("UTF-8");}
    }
    public static void writeText(Context context,Uri uri,String text)throws IOException {
        try(OutputStream out=new BufferedOutputStream(context.getContentResolver().openOutputStream(uri,"wt"))) {if(out==null)throw new IOException("Cannot open destination document");byte[] b=(text==null?"":text).getBytes(java.nio.charset.StandardCharsets.UTF_8);out.write(b);out.flush();}
    }
    public static void copyTreeToDirectory(Context context,Uri treeUri,File destination)throws IOException { copyTreeToDirectory(context,treeUri,destination,null); }
    public static void copyTreeToDirectory(Context context,Uri treeUri,File destination,CancelCheck cancel)throws IOException {
        DocumentFile tree=DocumentFile.fromTreeUri(context,treeUri);if(tree==null||!tree.isDirectory())throw new IOException("Selected folder cannot be opened");if(!destination.isDirectory()&&!destination.mkdirs())throw new IOException("Cannot create working folder");copyDocumentChildren(context,tree,destination,cancel);
    }
    private static void copyDocumentChildren(Context context,DocumentFile parent,File target,CancelCheck cancel)throws IOException {
        check(cancel);DocumentFile[] children=parent.listFiles();if(children==null)throw new IOException("Cannot list selected folder");for(DocumentFile child:children){check(cancel);String name=FileHelper.sanitizeFilename(child.getName());File out=new File(target,name).getCanonicalFile();if(!out.getParentFile().equals(target.getCanonicalFile()))throw new IOException("Unsafe selected filename");if(out.exists())throw new IOException("Two selected items resolve to the same safe name: "+name);if(child.isDirectory()){if(!out.mkdirs())throw new IOException("Cannot create "+out);copyDocumentChildren(context,child,out,cancel);}else if(child.isFile()){try(InputStream in=context.getContentResolver().openInputStream(child.getUri());FileOutputStream fos=new FileOutputStream(out)){if(in==null)throw new IOException("Cannot read "+name);copy(in,fos,cancel);fos.getFD().sync();}}}
    }
    public static void copyDirectoryToTree(Context context,File source,Uri treeUri)throws IOException { copyDirectoryToTree(context,source,treeUri,null); }
    public static void copyDirectoryToTree(Context context,File source,Uri treeUri,CancelCheck cancel)throws IOException {
        DocumentFile root=DocumentFile.fromTreeUri(context,treeUri);if(root==null||!root.isDirectory())throw new IOException("Destination folder cannot be opened");copyFilesToDocumentTree(context,source,root,cancel);
    }
    private static void copyFilesToDocumentTree(Context context,File source,DocumentFile target,CancelCheck cancel)throws IOException {
        check(cancel);File[] files=source.listFiles();if(files==null)throw new IOException("Cannot list output folder");for(File f:files){check(cancel);String name=FileHelper.sanitizeFilename(f.getName());if(f.isDirectory()){DocumentFile d=target.findFile(name);if(d==null)d=target.createDirectory(name);if(d==null||!d.isDirectory())throw new IOException("Cannot create destination folder "+name);copyFilesToDocumentTree(context,f,d,cancel);}else if(f.isFile()){DocumentFile existing=target.findFile(name);if(existing!=null&&!existing.delete())throw new IOException("Cannot replace destination file "+name);DocumentFile dest=target.createFile("application/octet-stream",name);if(dest==null)throw new IOException("Cannot create destination file "+name);try(InputStream in=new BufferedInputStream(new FileInputStream(f));OutputStream out=context.getContentResolver().openOutputStream(dest.getUri(),"wt")){if(out==null)throw new IOException("Cannot write "+name);copy(in,out,cancel);out.flush();}}}
    }
    private static void copy(InputStream in,OutputStream out)throws IOException {copy(in,out,null);}
    private static void copy(InputStream in,OutputStream out,CancelCheck cancel)throws IOException {byte[] b=new byte[BUFFER];int n;while(true){check(cancel);n=in.read(b);if(n==-1)break;out.write(b,0,n);}}
    private static void check(CancelCheck cancel)throws IOException {if(cancel!=null&&cancel.isCancelled())throw new IOException("Operation cancelled");}
}
