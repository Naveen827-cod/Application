/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

/** Progress notifications for long-running local file operations. */
public interface ProgressCallback {
    void onProgress(int current, int total, String message);
    void onComplete(String result);
    void onError(String message, Throwable t);
    void onLog(String message);
}
