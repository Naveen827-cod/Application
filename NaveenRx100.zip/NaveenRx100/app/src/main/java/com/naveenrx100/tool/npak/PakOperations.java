/*
 * NaveenRx100 Tool - Generic PakOperations
 * EDUCATIONAL PURPOSE ONLY. UI-friendly wrappers for synthetic NPAK operations.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class PakOperations {
    public interface Callback extends PakRepacker.ProgressCallback {}
    private PakOperations(){}
    public static int extractAll(File pak,File out,byte[] key,Callback cb,AtomicBoolean cancel)throws IOException{return PakRepacker.extractAll(pak,out,key,cb,cancel);}
    public static int repack(File pak,File edited,File out,boolean forceAdd,Callback cb,AtomicBoolean cancel)throws IOException{return PakRepacker.repack(pak,edited,out,forceAdd,null,cb,cancel);}
    public static int buildNew(File template,File edited,File out,Callback cb,AtomicBoolean cancel)throws IOException{return PakBuilder.buildNew(template,edited,out,cb,cancel);}
    public static int inject(File pak,List<InjectItem> items,File out,Callback cb,AtomicBoolean cancel)throws IOException{return PakInjector.inject(pak,items,out,cb,cancel);}
}
