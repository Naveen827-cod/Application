/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import com.naveenrx100.tool.R;
import java.io.File;

public final class SettingsActivity extends ToolScreenActivity {
    private TextView themeValue;
    private static final String PREFS = "naveenrx100_settings";
    private static final String THEME_KEY = "theme";
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_settings);
        NavHelper.bindToolbar(this, "Settings", "⚙");
        NavHelper.bindBottomNav(this);
        themeValue = findViewById(R.id.themeValue);
        refreshTheme();
        findViewById(R.id.rowTheme).setOnClickListener(v -> chooseTheme());
        findViewById(R.id.clearCacheButton).setOnClickListener(v -> clearCache());
        findViewById(R.id.rowSettingsAbout).setOnClickListener(v -> NavHelper.go(this, AboutActivity.class));
        TextView paths = findViewById(R.id.defaultPathsText);
        paths.setText("App files: " + getFilesDir().getAbsolutePath() + "\nCache: " + getCacheDir().getAbsolutePath() + "\nFiles are selected through Android's document picker.");
    }
    private void refreshTheme() {
        String theme = getSharedPreferences(PREFS, MODE_PRIVATE).getString(THEME_KEY, "Natural");
        themeValue.setText(theme);
    }
    private void chooseTheme() {
        final String[] themes = {"Light", "Dark", "Natural"};
        String current = themeValue.getText().toString();
        int checked = current.equals("Light") ? 0 : current.equals("Dark") ? 1 : 2;
        new AlertDialog.Builder(this).setTitle("Choose theme")
                .setSingleChoiceItems(themes, checked, (dialog, which) -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(THEME_KEY, themes[which]).apply();
                    themeValue.setText(themes[which]);
                    dialog.dismiss();
                    Toast.makeText(this, "Theme preference saved. Full live theme switching is not enabled in this build.", Toast.LENGTH_LONG).show();
                }).setNegativeButton("Cancel", null).show();
    }
    private void clearCache() {
        boolean ok = deleteContents(getCacheDir());
        Toast.makeText(this, ok ? "Cache cleared." : "Some cache files could not be removed.", Toast.LENGTH_LONG).show();
    }
    private boolean deleteContents(File dir) {
        boolean success = true;
        File[] files = dir.listFiles();
        if (files == null) return true;
        for (File file : files) {
            if (file.isDirectory()) success &= deleteContents(file);
            if (!file.delete()) success = false;
        }
        return success;
    }
}
