/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.app.AlertDialog;
import android.os.Bundle;
import com.naveenrx100.tool.R;

public final class InjectActivity extends ToolScreenActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_inject);
        NavHelper.bindToolbar(this, "Inject Tool", "⚡");
        NavHelper.bindBottomNav(this);
        findViewById(R.id.rowSelectProcess).setOnClickListener(v -> explain("Select Process", "In a real diagnostic tool, this would display processes that the user is authorized to inspect. This app does NOT inspect or inject into live games."));
        findViewById(R.id.rowInjectScript).setOnClickListener(v -> explain("Inject Script", "In a controlled lab, this could demonstrate loading a test module into a process owned by the developer. This app does NOT inject Lua, DLLs, or code into live games."));
        findViewById(R.id.rowManageInjection).setOnClickListener(v -> explain("Manage Injection", "A lab-only manager might list test modules started by its own simulator. This app does NOT track or control running game injections."));
        findViewById(R.id.rowClearInjection).setOnClickListener(v -> explain("Clear Injection", "A safe demo could reset its own simulated state. This app does NOT stop, modify, or clear code in another running process."));
    }

    private void explain(String title, String detail) {
        new AlertDialog.Builder(this).setTitle(title)
                .setMessage("Educational demonstration only.\n\n" + detail)
                .setPositiveButton("I Understand", null).show();
    }
}
