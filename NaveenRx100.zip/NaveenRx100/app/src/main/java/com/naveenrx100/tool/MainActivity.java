/*
 * NaveenRx100 Tool - MainActivity
 * EDUCATIONAL PURPOSE ONLY. Demonstrates a simple Android activity entry point.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** Kept as a lightweight sample activity; the manifest launcher is WelcomeActivity. */
public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        TextView tv=findViewById(R.id.sample_text);
        if(tv!=null)tv.setText("NaveenRx100 Tool • Educational build");
    }
}
