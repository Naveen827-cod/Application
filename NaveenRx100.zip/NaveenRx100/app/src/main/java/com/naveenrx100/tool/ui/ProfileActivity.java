/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import com.naveenrx100.tool.R;

public final class ProfileActivity extends ToolScreenActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_profile);
        NavHelper.bindToolbar(this, "Profile", "👤");
        NavHelper.bindBottomNav(this);
        findViewById(R.id.rowProfileSettings).setOnClickListener(v -> NavHelper.go(this, SettingsActivity.class));
        findViewById(R.id.rowProfileAbout).setOnClickListener(v -> NavHelper.go(this, AboutActivity.class));
        findViewById(R.id.rowProfileHelp).setOnClickListener(v -> NavHelper.go(this, HelpActivity.class));
        findViewById(R.id.rowShareApp).setOnClickListener(v -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, "NaveenRx100 Tool v1.0.0 — Education Purpose Only.");
            startActivity(Intent.createChooser(share, "Share app information"));
        });
        findViewById(R.id.rowExitApp).setOnClickListener(v -> finishAffinity());
    }
}
