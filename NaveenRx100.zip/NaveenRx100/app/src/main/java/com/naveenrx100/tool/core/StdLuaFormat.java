/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.Arrays;

/** Standard Lua 5.3 chunk constants and header validation helpers. */
public final class StdLuaFormat {
    public static final byte[] SIGNATURE = new byte[]{0x1b,'L','u','a'};
    public static final int VERSION_53 = 0x53;
    public static final int HEADER_SIZE = 33;
    private StdLuaFormat() {}
    public static boolean hasSignature(byte[] data) { return data != null && data.length >= 4 && Arrays.equals(SIGNATURE, Arrays.copyOf(data,4)); }
    public static void validate(byte[] data) {
        if (data == null || data.length < HEADER_SIZE + 1) throw new IllegalArgumentException("Lua bytecode is truncated");
        if (!hasSignature(data)) throw new IllegalArgumentException("Not a valid Lua bytecode file");
        if ((data[4] & 0xff) != VERSION_53) throw new IllegalArgumentException(String.format("Unsupported Lua version 0x%02X (expected 0x53)", data[4] & 0xff));
        int sizeT=data[13]&0xff;
        if (sizeT!=4 && sizeT!=8) throw new IllegalArgumentException("Unsupported size_t width: " + sizeT);
    }
}
