# Keep reflection-accessed methods/classes when adding the Lua decompiler integration.
-keepattributes *Annotation*
