# NaveenRx100 Tool — Educational Android Project

**EDUCATIONAL PURPOSE ONLY.** This project demonstrates Android file selection, streaming I/O, binary serialization, integrity checks, generic AES-GCM encryption, and standard Lua source editing.

## Supported archive format

The active archive tools support only **NPAK v1**, a synthetic format defined in `docs/NPAK_V1_FORMAT.md`. They do not parse or write proprietary game archives.

## Quick checks

Run the platform-independent synthetic tests with a JDK:

```sh
sh tools/run-synthetic-tests.sh
```

This test command compiles the generic NPAK core with `javac` and runs the self-test suite. It does not build the Android APK.

## Android build

See `docs/BUILD_ANDROID_STUDIO.md`. The project targets Android SDK 35, minimum SDK 24, and Java 8 source compatibility. Use JDK 17 with Android Gradle Plugin 8.6.1 and Gradle 8.7.

The environment used for this review had no Android SDK, no installed Gradle, and no network access, so an APK could not be produced here. `gradle-wrapper.properties` is present, but the wrapper bootstrap JAR is not included; the build guide explains how to generate the official wrapper using Gradle 8.7.

## Scope and source preservation

The app source set contains the generic NPAK implementation and standard Lua source tooling. Older version-specific archive/bytecode modules are preserved under `legacy-source/` for historical reference, but are deliberately excluded from the Android build and are not shipped in the APK. See `LIMITATIONS.md`.
