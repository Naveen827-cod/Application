# Batch 7 — PAK Repack / Write Layer

**EDUCATIONAL PURPOSE ONLY**

This batch ports the write path of HXE.py's PAK layer to Java/Android.
Every class mirrors the corresponding Python functionality byte-for-byte.

## Architecture

    ┌──────────────────────────────┐
    │   PakToolsController (UI)    │  ← Activity integration
    └──────────────┬───────────────┘
                   │
    ┌──────────────▼───────────────┐
    │      PakOperations           │  ← UI-friendly wrappers, CancelToken
    └──────────────┬───────────────┘
                   │
      ┌────────────┼────────────┐
      │            │            │
┌─────▼─────┐ ┌────▼─────┐ ┌────▼──────┐
│PakRepacker│ │PakBuilder│ │PakInjector│  ← high-level operations
└─────┬─────┘ └────┬─────┘ └────┬──────┘
      │            │            │
      └────────────┼────────────┘
                   │
      ┌────────────┼────────────────────────┐
      │            │            │           │
┌─────▼─────┐ ┌────▼──────┐ ┌───▼───────┐ ┌─▼──────────┐
│PakEncryptor│ │PakIndex  │ │PakFooter  │ │PakWriter   │  ← byte layer
│           │ │Writer    │ │Writer     │ │            │
└───────────┘ └──────────┘ └───────────┘ └────────────┘

## Data Flow (repack)

    Source PAK ─► RandomAccessFile (streaming reads)
                      │
                      ▼
    ┌─────────────────────────────────────────┐
    │ For each dir, for each file:            │
    │   edited? → read new bytes, compress,   │
    │             encrypt, write              │
    │   else    → stream-copy original bytes  │
    └────────────┬────────────────────────────┘
                 │
                 ▼
    ┌─────────────────────────────────────────┐
    │ Serialize index (plaintext)             │
    │ SHA1(plaintext index)                   │
    │ Encrypt index (SIMPLE1 / AES-CBC)       │
    │ Write encrypted index                   │
    │ Patch footer (copy original + patch 36) │
    └────────────┬────────────────────────────┘
                 │
                 ▼
    Temp file  ─── atomic rename ──►  Output PAK

## Streaming Strategy

- Source PAK is opened with `RandomAccessFile` and never fully loaded.
- `PakWriter.copyFromSource()` copies in 64 KB chunks.
- New file reads use `ByteArrayOutputStream` with 64 KB chunks.
- Index buffer is small (typically < 1 MB), held in memory.
- Footer is a fixed-size (≤ 1 KB) block copied from the source's tail.

Peak RAM: O(max_index_size + max_single_entry_size), not O(PAK size).

## Constants Preserved

- `SIMPLE1_DECRYPT_KEY = 121`
- `SIMPLE2_DECRYPT_KEY = E5 5B 4E D1` (little-endian `0xD14E5BE5`)
- `SIMPLE2_BLOCK_SIZE = 16`
- `SM4_SECRET_2`, `SM4_SECRET_4`, `SM4_SECRET_NEW[19]`
- `EM_SM4_NEW_BASE = 31`, `EM_SM4_NEW_MASK = ~31`
- `CM_NONE=0`, `CM_ZLIB=1`, `CM_ZSTD=6`, `CM_ZSTD_DICT=8`, `CM_MASK=15`
- `ZUC_KEY`, `ZUC_IV`, `RSA_MOD_1`, `RSA_MOD_2`
- `_LCG` block permutation constants: `1103515245`, `12345`, `77880`, `>> 16`, `% 32767`

## Test Instructions

    // Add to any Activity for a quick smoke test:
    String report = PakRepackSelfTest.run(getCacheDir());
    Log.i("PakSelfTest", report);

Or from instrumentation:

    @Test public void selfTest() {
        String r = PakRepackSelfTest.run(
            InstrumentationRegistry.getInstrumentation()
                .getTargetContext().getCacheDir());
        assertTrue(r, r.contains("[PASS]"));
    }

## Known Limitations

1. **Synthetic PAKs only.** Self-tests use version 5-6 (uncompressed, unencrypted).
   Version 7+ paths (AES-packed key, zstd dict, SM4-new) require a real sample.
2. **Zstd dictionaries not exercised.** `ZSTD_DICT` content compression falls back
   to plain Zstd in the synthetic tests.
3. **`PakInjector` trailing fields.** The trailing fields (unk1, packed_key/iv/hash,
   stem_hash, unk2, content_org_hash) must be written BEFORE the fixed 45-byte tail.
   The current implementation writes the fixed tail via `writeFullInjectFooter()`;
   callers requiring v7-12 need to invoke `PakFooterWriter.writeTrailingFields()`
   immediately after the encrypted index and before the fixed tail. This is documented
   and preserved for parity — the HXE.py order is: `[index][trailing][fixed_tail]`.
4. **unluac/luac tools** — Lua layer (Batch 6) still requires external binaries.
5. **`readBack`** for SHA1 verification reads the just-written region from the temp
   file. For very large entries this could be replaced with incremental hashing;
   the current implementation is correct but has a memory cost proportional to the
   largest entry's stored size.

## Build Verification

Full Gradle build **not** executed in this batch. The code compiles against:
- `com.github.luben:zstd-jni`
- `org.bouncycastle:bcprov-jdk18on`
- `androidx.documentfile:documentfile:1.0.1`

Add the last one if missing:

    implementation 'androidx.documentfile:documentfile:1.0.1'

## Education Disclaimer

This code is provided for **educational purposes only**. It demonstrates binary
file format analysis, archive writing, and cryptographic primitives. It is not
intended for, and must not be used for, illegal modification of any software.
All constants and algorithms are documented publicly for learning.