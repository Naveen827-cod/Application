/*
 * NaveenRx100 Tool - PakFooterWriter
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.pak;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Writes or patches the PAK footer.
 *
 * <p>There are two usage patterns in HXE.py:</p>
 *
 * <ol>
 *   <li><b>Repack path</b>: copy the original footer verbatim, then patch the
 *       last 36 bytes:
 *       <pre>
 *       new_footer[-36:-16] = XOR(sha1, pack('&lt;5I', keystream[4:9]))
 *       new_footer[-16:-8]  = index_size ^ ((ks[10]&lt;&lt;32) | ks[11])
 *       new_footer[-8:]     = index_offset ^ ((ks[0]&lt;&lt;32) | ks[1])
 *       </pre>
 *   </li>
 *   <li><b>Inject path</b>: emit the full footer from scratch, field by
 *       field, encrypted with the ZUC keystream.</li>
 * </ol>
 */
public final class PakFooterWriter {

    private PakFooterWriter() {}

    // ---------------------------------------------------------------
    // Repack path — patch the copied footer
    // ---------------------------------------------------------------
    /**
     * Patches a copied footer byte array in place. The array must be the
     * exact number of bytes returned by {@code TencentPakInfo._mem_size(version)}.
     *
     * @param footer         footer bytes (will be mutated)
     * @param indexSha1      20-byte SHA1 of the plaintext index
     * @param indexSize      encrypted index size
     * @param indexOffset    encrypted index offset (file offset)
     * @param keystream      16 × uint32 keystream (as little-endian ints)
     */
    public static void patchFooter(byte[] footer,
                                   byte[] indexSha1,
                                   long indexSize,
                                   long indexOffset,
                                   int[] keystream) {
        if (footer == null || footer.length < 36) {
            throw new IllegalArgumentException("footer too small to patch");
        }
        if (indexSha1 == null || indexSha1.length != 20) {
            throw new IllegalArgumentException("indexSha1 must be 20 bytes");
        }

        int n = footer.length;
        // [n-36, n-16) = encrypted_index_hash (20 bytes)
        byte[] hashKey = packLe5Ints(
                keystream[4], keystream[5], keystream[6], keystream[7], keystream[8]);
        for (int i = 0; i < 20; i++) {
            footer[n - 36 + i] = (byte) (indexSha1[i] ^ hashKey[i]);
        }

        // [n-16, n-8) = encrypted_index_size
        long sizeKey = ((long) keystream[10] << 32) | (keystream[11] & 0xFFFFFFFFL);
        putLe64(footer, n - 16, indexSize ^ sizeKey);

        // [n-8, n) = encrypted_index_offset
        long offKey = ((long) keystream[0] << 32) | (keystream[1] & 0xFFFFFFFFL);
        putLe64(footer, n - 8, indexOffset ^ offKey);
    }

    // ---------------------------------------------------------------
    // Inject path — write footer from scratch
    // ---------------------------------------------------------------
    /**
     * Writes the full footer as HXE.py's inject_files() does.
     * Field ordering is critical; see the HXE.py tail.
     */
    public static void writeFullFooter(PakWriter w,
                                       TencentPakInfo info,
                                       byte[] indexSha1,
                                       long indexSize,
                                       long indexOffset,
                                       int[] keystream) throws IOException {
        int version = info.version();

        // [1] encrypted_flag_byte
        int flagPlain = info.indexEncrypted() ? 1 : 0;
        w.writeByte(flagPlain ^ (keystream[3] & 0xFF));

        // [2] encrypted_magic (4 bytes)
        w.writeUint32LE((info.magic() ^ keystream[2]) & 0xFFFFFFFFL);

        // [3] version (4 bytes)
        w.writeUint32LE(version & 0xFFFFFFFFL);

        // [4] encrypted_index_hash (20 bytes) — zeros if version < 6
        if (version >= 6) {
            byte[] hashKey = packLe5Ints(
                    keystream[4], keystream[5], keystream[6], keystream[7], keystream[8]);
            byte[] enc = new byte[20];
            for (int i = 0; i < 20; i++) {
                enc[i] = (byte) (indexSha1[i] ^ hashKey[i]);
            }
            w.writeBytes(enc);
        } else {
            w.writeBytes(new byte[20]);
        }

        // [5] encrypted_index_size (8 bytes)
        long sizeKey = ((long) keystream[10] << 32) | (keystream[11] & 0xFFFFFFFFL);
        w.writeUint64LE(indexSize ^ sizeKey);

        // [6] encrypted_index_offset (8 bytes)
        long offKey = ((long) keystream[0] << 32) | (keystream[1] & 0xFFFFFFFFL);
        w.writeUint64LE(indexOffset ^ offKey);
    }

    /**
     * Writes the <em>trailing</em> version-specific fields (unk1, packed_key,
     * packed_iv, packed_index_hash, stem_hash, unk2, content_org_hash) — these
     * come <b>after</b> the encrypted index bytes and <b>before</b> the
     * 45-byte "fixed" tail written by {@link #writeFullFooter}. This mirrors
     * HXE.py's inject_files() footer layout, where the fixed tail is written
     * LAST.
     */
    public static void writeTrailingFields(PakWriter w,
                                           TencentPakInfo info,
                                           int[] keystream) throws IOException {
        int version = info.version();

        // version >= 7: encrypted unk1 (32 bytes)
        if (version >= 7) {
            byte[] key = packLe8Ints(
                    keystream[7], keystream[8], keystream[9], keystream[10],
                    keystream[11], keystream[12], keystream[13], keystream[14]);
            byte[] unk1 = info.unk1();
            if (unk1 == null || unk1.length != 32) unk1 = new byte[32];
            byte[] enc = new byte[32];
            for (int i = 0; i < 32; i++) enc[i] = (byte) (unk1[i] ^ key[i]);
            w.writeBytes(enc);
        }
        // version >= 8: packed_key/iv/hash raw (256 each)
        if (version >= 8) {
            w.writeBytes(nullToZeros(info.packedKey(), 256));
            w.writeBytes(nullToZeros(info.packedIv(), 256));
            w.writeBytes(nullToZeros(info.packedIndexHash(), 256));
        }
        // version >= 9: stem_hash and unk2 (each uint32 XOR keystream[8]/[9])
        if (version >= 9) {
            w.writeUint32LE(((long) info.stemHash() ^ (keystream[8] & 0xFFFFFFFFL)) & 0xFFFFFFFFL);
            w.writeUint32LE(((long) info.unk2Value() ^ (keystream[9] & 0xFFFFFFFFL)) & 0xFFFFFFFFL);
        }
        // version >= 12: content_org_hash (20 bytes, raw)
        if (version >= 12) {
            w.writeBytes(nullToZeros(info.contentOrgHash(), 20));
        }
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------
    private static byte[] packLe5Ints(int a, int b, int c, int d, int e) {
        ByteBuffer bb = ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(a).putInt(b).putInt(c).putInt(d).putInt(e);
        return bb.array();
    }

    private static byte[] packLe8Ints(int... ints) {
        ByteBuffer bb = ByteBuffer.allocate(4 * ints.length).order(ByteOrder.LITTLE_ENDIAN);
        for (int i : ints) bb.putInt(i);
        return bb.array();
    }

    private static void putLe64(byte[] arr, int off, long v) {
        for (int i = 0; i < 8; i++) {
            arr[off + i] = (byte) ((v >>> (8 * i)) & 0xFF);
        }
    }

    private static byte[] nullToZeros(byte[] in, int size) {
        if (in == null) return new byte[size];
        if (in.length == size) return in;
        byte[] out = new byte[size];
        System.arraycopy(in, 0, out, 0, Math.min(in.length, size));
        return out;
    }
}