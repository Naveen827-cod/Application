/*
 * NaveenRx100 Tool - PakBuilder
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.pak;

import com.github.luben.zstd.Zstd;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Port of HXE.py {@code build_new_pak_from_template}.
 */
public final class PakBuilder {

    public interface ProgressCallback {
        void onFile(int processed, int total, String path);
        void onStage(String stage);
    }

    private PakBuilder() {}

    public static int build(File templatePak, File editDir, File outputPak,
                            String targetPath,
                            Map<String, String> pathMap,
                            ProgressCallback cb) throws IOException {

        List<File> editFiles = listFilesRecursive(editDir);
        if (editFiles.isEmpty()) return 0;

        try (TencentPakFile template = TencentPakFile.open(templatePak)) {
            int version = template.version();
            int[] keystream = PakCrypto.zucKeystream();
            String mountPoint = template.mountPoint();

            TencentPakEntry templateEntry = null;
            outer:
            for (Map<String, TencentPakEntry> d : template.index().values()) {
                for (TencentPakEntry e : d.values()) { templateEntry = e; break outer; }
            }
            if (templateEntry == null) return 0;

            List<TencentPakEntry> newFiles = new ArrayList<>();
            LinkedHashMap<String, LinkedHashMap<String, Integer>> dirTable =
                    new LinkedHashMap<>();

            try (RandomAccessFile srcRaf = new RandomAccessFile(templatePak, "r");
                 PakWriter w = new PakWriter(outputPak, srcRaf)) {

                int idx = 0;
                for (File p : editFiles) {
                    if (cb != null && cb.isCancelledSafe()) throw new IOException("Cancelled");
                    String rel = relativize(editDir, p).replace('\\', '/');
                    String dirKey;
                    String fp;
                    if (pathMap != null) {
                        String tp = pathMap.get(p.getName());
                        if (tp == null) tp = "";
                        if (tp.isEmpty()) {
                            dirKey = dirOf(rel);
                            fp = rel;
                        } else {
                            dirKey = trimSlash(tp) + "/";
                            fp = trimSlash(tp) + "/" + p.getName();
                        }
                    } else if (targetPath != null && !targetPath.isEmpty()) {
                        dirKey = trimSlash(targetPath) + "/";
                        fp = trimSlash(targetPath) + "/" + p.getName();
                    } else {
                        dirKey = dirOf(rel);
                        fp = rel;
                    }

                    TencentPakEntry ne = templateEntry.copy();
                    byte[] raw = readAll(p);
                    String pakRel = fp;
                    int cm = templateEntry.compressionMethod();
                    int em = templateEntry.encryptionMethod();
                    boolean encrypted = templateEntry.encrypted();

                    ne.setUncompressedSize(raw.length);
                    ne.setCompressionMethod(cm);
                    ne.setEncryptionMethod(em);
                    ne.setEncrypted(encrypted);
                    ne.setUnk1(templateEntry.unk1());
                    String fullStr = (mountPoint == null ? "" : mountPoint) + fp;
                    ne.setUnk2(sha1(fullStr.toLowerCase(Locale.ROOT)
                            .getBytes(StandardCharsets.UTF_8)));
                    ne.setIndexNewSep(templateEntry.indexNewSep());

                    if (cm == PakConstants.CM_NONE) {
                        byte[] stored = encrypted
                                ? PakEncryptor.encryptContent(raw, pakRel, em) : raw;
                        ne.setOffset(w.position());
                        ne.setSize(raw.length);
                        w.writeBytes(stored);
                    } else {
                        int cs = templateEntry.compressionBlockSize() > 0
                                ? templateEntry.compressionBlockSize() : 0x10000;
                        List<byte[]> chunks = chunk(raw, cs);
                        int[] order = PakCrypto.generateBlockIndices(chunks.size(), em);
                        List<byte[]> cipherByLogical = new ArrayList<>();
                        for (byte[] chunk : chunks) {
                            byte[] comp = compress(chunk, cm);
                            byte[] cipher = encrypted
                                    ? PakEncryptor.encryptContent(comp, pakRel, em) : comp;
                            cipherByLogical.add(cipher);
                        }
                        int[] inv = new int[chunks.size()];
                        for (int i = 0; i < order.length; i++) inv[order[i]] = i;
                        List<PakCompressedBlock> blocks = new ArrayList<>();
                        for (int phys = 0; phys < chunks.size(); phys++) {
                            long s = w.position();
                            w.writeBytes(cipherByLogical.get(inv[phys]));
                            long e = w.position();
                            blocks.add(new PakCompressedBlock(s, e));
                        }
                        ne.setCompressedBlocks(blocks);
                        ne.setOffset(blocks.isEmpty() ? w.position() : blocks.get(0).start);
                        long total = 0;
                        for (PakCompressedBlock b : blocks) total += (b.end - b.start);
                        ne.setSize(total);
                    }

                    byte[] stored = w.readBack(ne.offset(),
                            (int) Math.min(ne.size(), Integer.MAX_VALUE));
                    ne.setContentHash(sha1(stored));

                    int fileIdx = idx++;
                    newFiles.add(ne);
                    dirTable.computeIfAbsent(dirKey, k -> new LinkedHashMap<>())
                            .put(p.getName(), fileIdx);

                    if (cb != null) cb.onFile(idx, editFiles.size(), fp);
                }

                if (cb != null) cb.onStage("Serializing index");

                byte[] indexPlain = PakIndexWriter.serialize(mountPoint, newFiles,
                        dirTable, version);
                byte[] indexSha1 = sha1(indexPlain);
                byte[] indexEnc = PakEncryptor.encryptIndex(indexPlain, template.pakInfo());

                long newIndexOffset = w.position();
                w.writeBytes(indexEnc);
                long newIndexSize = indexEnc.length;

                byte[] footer = template.readOriginalFooterBytes();
                PakFooterWriter.patchFooter(footer, indexSha1, newIndexSize,
                        newIndexOffset, keystream);
                w.writeBytes(footer);

                w.commit();
            }
            return newFiles.size();
        }
    }

    // helpers (duplicated from PakRepacker for locality)
    private static List<File> listFilesRecursive(File root) {
        List<File> out = new ArrayList<>();
        File[] ch = root.listFiles();
        if (ch == null) return out;
        for (File c : ch) {
            if (c.isFile()) out.add(c);
            else if (c.isDirectory()) out.addAll(listFilesRecursive(c));
        }
        return out;
    }
    private static byte[] readAll(File f) throws IOException {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[64 * 1024];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            return out.toByteArray();
        }
    }
    private static List<byte[]> chunk(byte[] src, int cs) {
        List<byte[]> out = new ArrayList<>();
        for (int i = 0; i < src.length; i += cs) {
            int e = Math.min(i + cs, src.length);
            byte[] c = new byte[e - i];
            System.arraycopy(src, i, c, 0, c.length);
            out.add(c);
        }
        if (out.isEmpty()) out.add(new byte[0]);
        return out;
    }
    private static byte[] compress(byte[] chunk, int cm) {
        if (cm == PakConstants.CM_ZLIB) {
            java.util.zip.Deflater def = new java.util.zip.Deflater(9);
            def.setInput(chunk); def.finish();
            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            while (!def.finished()) {
                int n = def.deflate(buf);
                baos.write(buf, 0, n);
            }
            def.end();
            return baos.toByteArray();
        }
        if (cm == PakConstants.CM_ZSTD || cm == PakConstants.CM_ZSTD_DICT) {
            int[] levels = {22, 19, 16, 13, 10, 7, 4, 1};
            for (int lvl : levels) {
                try {
                    long bound = Zstd.compressBound(chunk.length);
                    byte[] out = new byte[(int) bound];
                    long written = Zstd.compress(out, chunk, lvl);
                    if (Zstd.isError(written)) continue;
                    byte[] trimmed = new byte[(int) written];
                    System.arraycopy(out, 0, trimmed, 0, (int) written);
                    return trimmed;
                } catch (Throwable ignored) {}
            }
        }
        return chunk;
    }
    private static byte[] sha1(byte[] d) {
        try { return MessageDigest.getInstance("SHA-1").digest(d); }
        catch (Exception e) { throw new RuntimeException(e); }
    }
    private static String relativize(File root, File p) {
        String r = root.getAbsolutePath();
        String a = p.getAbsolutePath();
        if (a.startsWith(r)) {
            String rel = a.substring(r.length());
            while (rel.startsWith("/") || rel.startsWith("\\")) rel = rel.substring(1);
            return rel;
        }
        return p.getName();
    }
    private static String trimSlash(String s) {
        if (s == null) return "";
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
    private static String dirOf(String rel) {
        int i = rel.lastIndexOf('/');
        return i < 0 ? "" : rel.substring(0, i + 1);
    }
}