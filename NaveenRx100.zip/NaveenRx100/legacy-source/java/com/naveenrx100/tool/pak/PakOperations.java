/*
 * NaveenRx100 Tool - PakOperations
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.pak;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * High-level, UI-facing wrappers around the write layer.
 *
 * <p>Cancellation is cooperative: callers register a flag via
 * {@link Callback#cancel()} and the underlying operation checks it at
 * file boundaries.</p>
 */
public final class PakOperations {

    public interface Callback {
        void onStage(String stage);
        void onProgress(int current, int total, String label);
        void onError(String message, Throwable cause);
        void onDone(String message);
        boolean isCancelled();
    }

    /** Simple cancellable flag for callers that don't want to implement {@link Callback}. */
    public static final class CancelToken {
        private final AtomicBoolean cancelled = new AtomicBoolean(false);
        public void cancel() { cancelled.set(true); }
        public boolean isCancelled() { return cancelled.get(); }
    }

    private PakOperations() {}

    // ---------------------------------------------------------------
    // extractAll — reuse Batch 5 reader but expose progress
    // ---------------------------------------------------------------
    public static boolean extractAll(File pakFile, File outDir, Callback cb) {
        try {
            try (TencentPakFile pak = TencentPakFile.open(pakFile)) {
                if (cb != null) cb.onStage("Extracting");
                pak.dump(outDir, (done, total, name) -> {
                    if (cb != null) {
                        cb.onProgress(done, total, name);
                        if (cb.isCancelled()) throw new RuntimeException("Cancelled");
                    }
                });
            }
            if (cb != null) cb.onDone("Extract complete");
            return true;
        } catch (Throwable t) {
            if (cb != null) cb.onError("Extract failed", t);
            return false;
        }
    }

    // ---------------------------------------------------------------
    // repack
    // ---------------------------------------------------------------
    public static boolean repack(File pakFile, File editedDir, File outPak,
                                 String targetPath, boolean forceAdd,
                                 Map<String, String> pathMap, Callback cb) {
        try {
            if (cb != null) cb.onStage("Opening PAK");
            try (TencentPakFile pak = TencentPakFile.open(pakFile)) {
                int n = PakRepacker.repack(pak, editedDir, outPak, targetPath,
                        forceAdd, pathMap, new PakRepacker.ProgressCallback() {
                            @Override public void onFile(int p, int t, String path) {
                                if (cb != null) cb.onProgress(p, t, path);
                            }
                            @Override public void onStage(String s) {
                                if (cb != null) cb.onStage(s);
                            }
                            @Override public boolean isCancelled() {
                                return cb != null && cb.isCancelled();
                            }
                        });
                if (cb != null) cb.onDone("Repacked " + n + " file(s)");
                return n >= 0;
            }
        } catch (Throwable t) {
            if (cb != null) cb.onError("Repack failed", t);
            return false;
        }
    }

    // ---------------------------------------------------------------
    // buildNew
    // ---------------------------------------------------------------
    public static boolean buildNew(File templatePak, File editDir, File outPak,
                                   String targetPath, Map<String, String> pathMap,
                                   Callback cb) {
        try {
            if (cb != null) cb.onStage("Building new PAK");
            int n = PakBuilder.build(templatePak, editDir, outPak, targetPath,
                    pathMap, new PakBuilder.ProgressCallback() {
                        @Override public void onFile(int p, int t, String path) {
                            if (cb != null) cb.onProgress(p, t, path);
                        }
                        @Override public void onStage(String s) {
                            if (cb != null) cb.onStage(s);
                        }
                    });
            if (cb != null) cb.onDone("Built new PAK with " + n + " file(s)");
            return n > 0;
        } catch (Throwable t) {
            if (cb != null) cb.onError("Build failed", t);
            return false;
        }
    }

    // ---------------------------------------------------------------
    // inject
    // ---------------------------------------------------------------
    public static boolean inject(File pakFile, List<PakInjector.InjectItem> plan,
                                 File outPak, boolean addMarker, Callback cb) {
        try {
            if (cb != null) cb.onStage("Injecting");
            try (TencentPakFile pak = TencentPakFile.open(pakFile)) {
                int n = PakInjector.inject(pak, plan, outPak, addMarker,
                        new PakInjector.ProgressCallback() {
                            @Override public void onFile(int p, int t, String path) {
                                if (cb != null) cb.onProgress(p, t, path);
                            }
                            @Override public void onStage(String s) {
                                if (cb != null) cb.onStage(s);
                            }
                            @Override public boolean isCancelled() {
                                return cb != null && cb.isCancelled();
                            }
                        });
                if (cb != null) cb.onDone("Injected " + n + " file(s)");
                return n > 0;
            }
        } catch (Throwable t) {
            if (cb != null) cb.onError("Inject failed", t);
            return false;
        }
    }
}