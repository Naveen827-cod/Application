/*
 * NaveenRx100 Tool - PakIndexWriter
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.pak;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * Serializes the plaintext PAK index.
 *
 * <p>Byte layout exactly matches HXE.py:
 * <pre>
 *   writeUint32LE(len(mount_point_bytes))
 *   writeBytes(mount_point_bytes)
 *   writeUint32LE(num_files)
 *   for each file: writeEntry(entry, version)
 *   writeUint64LE(num_dirs)
 *   for each dir:
 *       writeString(dir_path + "/")   (or empty for root)
 *       writeUint64LE(num_files_in_dir)
 *       for each file:
 *           writeString(file_name)
 *           writeInt32LE(~file_index)
 * </pre>
 */
public final class PakIndexWriter {

    private PakIndexWriter() {}

    // ---------------------------------------------------------------
    // Entry serialization — matches HXE.py _pw_entry(entry, version)
    // ---------------------------------------------------------------
    public static void writeEntry(PakWriter w, TencentPakEntry e, int version)
            throws IOException {
        // content_hash: 20 bytes
        byte[] hash = e.contentHash();
        if (hash == null || hash.length != 20) {
            throw new IOException("Entry content_hash must be 20 bytes");
        }
        w.writeBytes(hash);

        // offset: uint64
        w.writeUint64LE(e.offset());

        // uncompressed_size: uint64
        w.writeUint64LE(e.uncompressedSize());

        // compression_method: uint32 (already masked with CM_MASK in HXE.py)
        w.writeUint32LE(e.compressionMethod() & PakConstants.CM_MASK);

        // size: uint64
        w.writeUint64LE(e.size());

        if (version >= 5) {
            w.writeByte(e.unk1() & 0xFF);
            byte[] u2 = e.unk2();
            if (u2 == null || u2.length != 20) {
                u2 = new byte[20];
            }
            w.writeBytes(u2, 0, 20);
        }

        if (e.compressionMethod() != PakConstants.CM_NONE && version >= 3) {
            List<PakCompressedBlock> blocks = e.compressedBlocks();
            int n = blocks == null ? 0 : blocks.size();
            w.writeUint32LE(n);
            if (blocks != null) {
                for (PakCompressedBlock b : blocks) {
                    w.writeUint64LE(b.start);
                    w.writeUint64LE(b.end);
                }
            }
        }

        if (version >= 4) {
            w.writeUint32LE(e.compressionBlockSize());
            w.writeByte(e.encrypted() ? 1 : 0);
        }

        if (version >= 12) {
            w.writeUint32LE(e.encryptionMethod());
            w.writeUint32LE(e.indexNewSep());
        }
    }

    // ---------------------------------------------------------------
    // Full index serialization
    // ---------------------------------------------------------------
    /**
     * @param mountPoint  raw mount-point string as read from the original index
     * @param entries     list of entries in the order they should appear in
     *                    the file table
     * @param dirTable    ordered directory table; file name → entry index
     *                    (index refers into {@code entries}); directories
     *                    WITHOUT trailing slash are stored as-is; the caller
     *                    is responsible for the trailing-slash convention
     *                    matching HXE.py's all_dirs keys.
     * @param version     PAK version
     */
    public static byte[] serialize(String mountPoint,
                                   List<TencentPakEntry> entries,
                                   Map<String, Map<String, Integer>> dirTable,
                                   int version) throws IOException {
        // We write to a memory buffer here (index is small), then return bytes.
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream(64 * 1024);
        // Wrap using a lightweight writer that reuses PakWriter logic.
        // We could construct PakWriter over a temp file, but the index is small
        // enough that memory is fine. However, to reuse the exact bytes from
        // PakWriter primitives, we create a "memory-backed" implementation.

        MemoryWriter mw = new MemoryWriter(baos);

        // mount point
        if (mountPoint == null || mountPoint.isEmpty()) {
            mw.writeInt32LE(0);
        } else {
            byte[] mp = mountPoint.getBytes(StandardCharsets.UTF_8);
            byte[] withNul = new byte[mp.length + 1];
            System.arraycopy(mp, 0, withNul, 0, mp.length);
            withNul[mp.length] = 0;
            mw.writeInt32LE(withNul.length);
            mw.writeBytes(withNul);
        }

        // entries
        mw.writeUint32LE(entries.size());
        for (TencentPakEntry e : entries) {
            writeEntryTo(mw, e, version);
        }

        // dir table
        mw.writeUint64LE(dirTable.size());
        for (Map.Entry<String, Map<String, Integer>> de : dirTable.entrySet()) {
            String dirKey = de.getKey();
            if (dirKey == null || dirKey.isEmpty() || ".".equals(dirKey)) {
                mw.writeInt32LE(0); // empty dir name
            } else {
                String withSlash = dirKey.endsWith("/") ? dirKey : dirKey + "/";
                mw.writeString(withSlash);
            }
            Map<String, Integer> files = de.getValue();
            mw.writeUint64LE(files.size());
            for (Map.Entry<String, Integer> fe : files.entrySet()) {
                mw.writeString(fe.getKey());
                // ~idx → negative one's complement
                int negOne = ~fe.getValue();
                mw.writeInt32LE(negOne);
            }
        }

        return baos.toByteArray();
    }

    // ---------------------------------------------------------------
    // Duplicated primitive-writers for the memory-backed path.
    // Kept identical to PakWriter's byte layout.
    // ---------------------------------------------------------------
    private static void writeEntryTo(MemoryWriter w, TencentPakEntry e, int version)
            throws IOException {
        byte[] hash = e.contentHash();
        if (hash == null || hash.length != 20) {
            throw new IOException("Entry content_hash must be 20 bytes");
        }
        w.writeBytes(hash);
        w.writeUint64LE(e.offset());
        w.writeUint64LE(e.uncompressedSize());
        w.writeUint32LE(e.compressionMethod() & PakConstants.CM_MASK);
        w.writeUint64LE(e.size());
        if (version >= 5) {
            w.writeByte(e.unk1() & 0xFF);
            byte[] u2 = e.unk2();
            if (u2 == null || u2.length != 20) u2 = new byte[20];
            w.writeBytes(u2, 0, 20);
        }
        if (e.compressionMethod() != PakConstants.CM_NONE && version >= 3) {
            List<PakCompressedBlock> blocks = e.compressedBlocks();
            int n = blocks == null ? 0 : blocks.size();
            w.writeUint32LE(n);
            if (blocks != null) {
                for (PakCompressedBlock b : blocks) {
                    w.writeUint64LE(b.start);
                    w.writeUint64LE(b.end);
                }
            }
        }
        if (version >= 4) {
            w.writeUint32LE(e.compressionBlockSize());
            w.writeByte(e.encrypted() ? 1 : 0);
        }
        if (version >= 12) {
            w.writeUint32LE(e.encryptionMethod());
            w.writeUint32LE(e.indexNewSep());
        }
    }

    /** Small memory-backed writer, same byte layout as PakWriter. */
    private static final class MemoryWriter {
        private final java.io.ByteArrayOutputStream out;
        MemoryWriter(java.io.ByteArrayOutputStream out) { this.out = out; }
        void writeByte(int v) { out.write(v & 0xFF); }
        void writeBytes(byte[] b) { out.write(b, 0, b.length); }
        void writeBytes(byte[] b, int o, int l) { out.write(b, o, l); }
        void writeInt32LE(int v) {
            out.write(v & 0xFF);
            out.write((v >>> 8) & 0xFF);
            out.write((v >>> 16) & 0xFF);
            out.write((v >>> 24) & 0xFF);
        }
        void writeUint32LE(long v) {
            out.write((int) (v & 0xFF));
            out.write((int) ((v >>> 8) & 0xFF));
            out.write((int) ((v >>> 16) & 0xFF));
            out.write((int) ((v >>> 24) & 0xFF));
        }
        void writeUint64LE(long v) {
            for (int i = 0; i < 8; i++) {
                out.write((int) ((v >>> (8 * i)) & 0xFF));
            }
        }
        void writeString(String s) throws IOException {
            if (s == null || s.isEmpty()) { writeInt32LE(0); return; }
            byte[] u = s.getBytes(StandardCharsets.UTF_8);
            byte[] withNul = new byte[u.length + 1];
            System.arraycopy(u, 0, withNul, 0, u.length);
            writeInt32LE(withNul.length);
            writeBytes(withNul);
        }
    }
}