/*
 * NaveenRx100 Tool - PakInjector
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.pak;

import com.github.luben.zstd.Zstd;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Port of HXE.py {@code TencentPakFile.inject_files}.
 *
 * <p>Injects additional files at internal paths, preserving the original
 * data region byte-for-byte, then appending new content and rebuilding
 * the index.</p>
 */
public final class PakInjector {

    public interface ProgressCallback {
        void onFile(int processed, int total, String path);
        void onStage(String stage);
        boolean isCancelled();
    }

    /** Simple immutable InjectItem container. */
    public static final class InjectItem {
        public final String internalPath;
        public final File source;
        public final int compMethod;
        public final int encMethod;
        public final boolean encrypted;
        public final int blockSize;
        public final int compLevel;

        public InjectItem(String internalPath, File source,
                          int compMethod, int encMethod,
                          boolean encrypted, int blockSize, int compLevel) {
            this.internalPath = internalPath;
            this.source = source;
            this.compMethod = compMethod;
            this.encMethod = encMethod;
            this.encrypted = encrypted;
            this.blockSize = blockSize;
            this.compLevel = compLevel;
        }
    }

    private PakInjector() {}

    public static int inject(TencentPakFile pak,
                             List<InjectItem> plan,
                             File outputPak,
                             boolean addSignatureMarker,
                             ProgressCallback cb) throws IOException {

        if (plan == null || plan.isEmpty()) return 0;

        int version = pak.version();
        int[] keystream = PakCrypto.zucKeystream();
        long originalIndexOffset = pak.indexOffset();

        if (cb != null) cb.onStage("Encoding inject files");

        // Prepare work items
        List<WorkItem> work = new ArrayList<>();
        for (InjectItem it : plan) {
            byte[] plain = readAll(it.source);
            String internal = it.internalPath.replace('\\', '/');
            while (internal.startsWith("/")) internal = internal.substring(1);
            if (internal.isEmpty()) continue;

            String dirStr, fileName;
            int slash = internal.lastIndexOf('/');
            if (slash >= 0) { dirStr = internal.substring(0, slash); fileName = internal.substring(slash + 1); }
            else { dirStr = ""; fileName = internal; }

            WorkItem wi = new WorkItem();
            wi.dirStr = dirStr;
            wi.fileName = fileName;
            wi.internalPath = internal;
            wi.plain = plain;
            wi.compMethod = it.compMethod;
            wi.encMethod = it.encMethod;
            wi.encrypted = it.encrypted;
            wi.blockSize = it.blockSize;
            wi.compLevel = it.compLevel;
            work.add(wi);
        }
        if (work.isEmpty()) return 0;

        // Use a temp output file. Since injection must copy the prefix [0, index_offset)
        // from source verbatim, we use a plain FileOutputStream rather than PakWriter.
        File parent = outputPak.getAbsoluteFile().getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        File tmp = File.createTempFile("nx_inj_" + outputPak.getName(), ".tmp", parent);

        long currentNewOffset = originalIndexOffset;
        List<TencentPakEntry> newEntries = new ArrayList<>();
        long written;

        try (RandomAccessFile src = new RandomAccessFile(pak.sourcePath(), "r");
             java.io.RandomAccessFile out = new java.io.RandomAccessFile(tmp, "rw")) {

            // [1] Copy original data region [0, index_offset).
            out.seek(0);
            copyRange(src, out, 0, originalIndexOffset);

            // [2] Encode and append each work item.
            int idx = 0;
            for (WorkItem wi : work) {
                if (cb != null && cb.isCancelled()) throw new IOException("Cancelled");
                TencentPakEntry ne = new TencentPakEntry();

                if (wi.plain.length == 0) {
                    ne.setContentHash(sha1(new byte[0]));
                    ne.setOffset(currentNewOffset);
                    ne.setUncompressedSize(0);
                    ne.setSize(0);
                    ne.setCompressionMethod(PakConstants.CM_NONE);
                    ne.setEncryptionMethod(0);
                    ne.setEncrypted(false);
                    ne.setCompressionBlockSize(0);
                    ne.setCompressedBlocks(new ArrayList<>());
                    ne.setUnk1(0);
                    ne.setUnk2(new byte[20]);
                    ne.setIndexNewSep(0);
                    newEntries.add(ne);
                    idx++;
                    if (cb != null) cb.onFile(idx, work.size(), wi.internalPath);
                    continue;
                }

                long entryStart;
                long entrySize;

                if (wi.compMethod == PakConstants.CM_NONE) {
                    byte[] stored;
                    if (wi.encrypted) {
                        long aligned = PakCrypto.alignEncryptedContentSize(
                                wi.plain.length, wi.encMethod);
                        byte[] padded = padZeros(wi.plain, (int) aligned);
                        stored = PakEncryptor.encryptContent(padded,
                                wi.fileName, wi.encMethod);
                    } else {
                        stored = wi.plain;
                    }
                    entryStart = currentNewOffset;
                    out.seek(currentNewOffset);
                    out.write(stored);
                    entrySize = stored.length;
                    currentNewOffset += entrySize;

                    ne.setOffset(entryStart);
                    ne.setSize(entrySize);
                    ne.setUncompressedSize(wi.plain.length);
                    ne.setCompressionMethod(PakConstants.CM_NONE);
                    ne.setEncryptionMethod(wi.encrypted ? wi.encMethod : 0);
                    ne.setEncrypted(wi.encrypted);
                    ne.setCompressionBlockSize(0);
                    ne.setCompressedBlocks(new ArrayList<>());
                } else {
                    int bs = wi.blockSize > 0 ? wi.blockSize : 0x10000;
                    List<byte[]> chunks = chunk(wi.plain, bs);
                    int[] order = PakCrypto.generateBlockIndices(chunks.size(), wi.encMethod);

                    // Compress + encrypt each chunk logically.
                    List<byte[]> cipherByLogical = new ArrayList<>();
                    for (byte[] c : chunks) {
                        byte[] compressed = compress(c, wi.compMethod, wi.compLevel);
                        byte[] cipher = wi.encrypted
                                ? PakEncryptor.encryptContent(compressed,
                                        wi.fileName, wi.encMethod)
                                : compressed;
                        cipherByLogical.add(cipher);
                    }

                    // Map logical→physical: physical_blocks[inv[i]] = cipherByLogical[i]
                    int[] inv = new int[chunks.size()];
                    for (int i = 0; i < order.length; i++) inv[order[i]] = i;

                    List<PakCompressedBlock> blocks = new ArrayList<>();
                    out.seek(currentNewOffset);
                    for (int phys = 0; phys < chunks.size(); phys++) {
                        long s = currentNewOffset;
                        byte[] b = cipherByLogical.get(inv[phys]);
                        out.write(b);
                        currentNewOffset += b.length;
                        blocks.add(new PakCompressedBlock(s, currentNewOffset));
                    }

                    long total = 0;
                    for (PakCompressedBlock b : blocks) total += (b.end - b.start);

                    ne.setOffset(blocks.isEmpty() ? currentNewOffset : blocks.get(0).start);
                    ne.setSize(total);
                    ne.setUncompressedSize(wi.plain.length);
                    ne.setCompressionMethod(wi.compMethod);
                    ne.setEncryptionMethod(wi.encrypted ? wi.encMethod : 0);
                    ne.setEncrypted(wi.encrypted);
                    ne.setCompressionBlockSize(bs);
                    ne.setCompressedBlocks(blocks);
                }

                // SHA1 of stored region.
                byte[] stored = new byte[(int) Math.min(ne.size(), Integer.MAX_VALUE)];
                out.seek(ne.offset());
                out.readFully(stored);
                ne.setContentHash(sha1(stored));

                ne.setUnk1(0);
                ne.setUnk2(new byte[20]);
                ne.setIndexNewSep(0);

                newEntries.add(ne);
                idx++;
                if (cb != null) cb.onFile(idx, work.size(), wi.internalPath);
            }

            if (addSignatureMarker) {
                // Check if marker already present in original index.
                boolean exists = false;
                for (Map<String, TencentPakEntry> d : pak.index().values()) {
                    for (String n : d.keySet()) {
                        if ("PATCHED.txt".equals(n) || "NaveenRx100".equalsIgnoreCase(n)) {
                            exists = true; break;
                        }
                    }
                    if (exists) break;
                }
                if (!exists) {
                    TencentPakEntry marker = new TencentPakEntry();
                    marker.setContentHash(sha1(new byte[0]));
                    marker.setOffset(currentNewOffset);
                    marker.setUncompressedSize(0);
                    marker.setSize(0);
                    marker.setCompressionMethod(PakConstants.CM_NONE);
                    marker.setEncryptionMethod(0);
                    marker.setEncrypted(false);
                    marker.setCompressionBlockSize(0);
                    marker.setCompressedBlocks(new ArrayList<>());
                    marker.setUnk1(0);
                    marker.setUnk2(new byte[20]);
                    marker.setIndexNewSep(0);
                    newEntries.add(marker);
                    // store the marker name separately for index writing
                    wiMarkerDir = "NaveenRx100";
                    wiMarkerName = "PATCHED.txt";
                }
            }

            // [3] Rebuild index from original entries + new entries.
            LinkedHashMap<String, LinkedHashMap<String, Integer>> dirTable = new LinkedHashMap<>();
            List<TencentPakEntry> allEntries = new ArrayList<>(pak.allEntriesInOrder());
            for (TencentPakEntry e : allEntries) {
                // no-op; populated below
            }
            // Original dirTable from pak
            String[] mountPointHolder = {pak.mountPoint()};
            LinkedHashMap<String, LinkedHashMap<String, Integer>> origDirs = pak.dirTable();
            int baseCount = allEntries.size();

            for (Map.Entry<String, LinkedHashMap<String, Integer>> de : origDirs.entrySet()) {
                LinkedHashMap<String, Integer> inner = new LinkedHashMap<>();
                for (Map.Entry<String, Integer> fe : de.getValue().entrySet()) {
                    inner.put(fe.getKey(), fe.getValue());
                }
                dirTable.put(de.getKey(), inner);
            }

            for (int i = 0; i < newEntries.size(); i++) {
                TencentPakEntry e = newEntries.get(i);
                allEntries.add(e);
            }

            // Place new entries in dir table.
            int newBase = baseCount;
            int ni = 0;
            for (WorkItem wi : work) {
                String dk = wi.dirStr.isEmpty() ? "" : (wi.dirStr.endsWith("/") ? wi.dirStr : wi.dirStr + "/");
                dirTable.computeIfAbsent(dk, k -> new LinkedHashMap<>())
                        .put(wi.fileName, newBase + ni);
                ni++;
            }
            if (wiMarkerDir != null) {
                dirTable.computeIfAbsent(wiMarkerDir + "/", k -> new LinkedHashMap<>())
                        .put(wiMarkerName, newBase + ni);
            }

            // Serialize index.
            byte[] indexPlain = PakIndexWriter.serialize(mountPointHolder[0], allEntries,
                    dirTable, version);
            byte[] indexSha1 = sha1(indexPlain);
            byte[] indexEnc = PakEncryptor.encryptIndex(indexPlain, pak.pakInfo());

            long indexOffsetOut = currentNewOffset;
            out.seek(currentNewOffset);
            out.write(indexEnc);
            currentNewOffset += indexEnc.length;

            // Footer: full rewrite (matches HXE.py inject_files tail).
            writeFullInjectFooter(out, pak.pakInfo(), indexSha1,
                    indexEnc.length, indexOffsetOut, keystream, currentNewOffset);

            out.getFD().sync();
        }

        // Atomic rename
        if (outputPak.exists()) outputPak.delete();
        if (!tmp.renameTo(outputPak)) {
            throw new IOException("Rename failed: " + tmp + " → " + outputPak);
        }
        return newEntries.size();
    }

    // State used during marker injection
    private static String wiMarkerDir = null;
    private static String wiMarkerName = null;

    // ---------------------------------------------------------------
    // Footer write for inject path
    // ---------------------------------------------------------------
    private static void writeFullInjectFooter(java.io.RandomAccessFile out,
                                              TencentPakInfo info,
                                              byte[] indexSha1,
                                              long indexSize,
                                              long indexOffset,
                                              int[] ks,
                                              long footerStart) throws IOException {
        int version = info.version();

        // 1. encrypted_flag_byte
        out.write((info.indexEncrypted() ? 1 : 0) ^ (ks[3] & 0xFF));
        // 2. encrypted_magic
        writeLe32(out, (info.magic() ^ ks[2]) & 0xFFFFFFFFL);
        // 3. version
        writeLe32(out, version & 0xFFFFFFFFL);
        // 4. encrypted_index_hash (20) or zeros
        if (version >= 6) {
            byte[] hashKey = le5Ints(ks[4], ks[5], ks[6], ks[7], ks[8]);
            for (int i = 0; i < 20; i++) {
                out.write((indexSha1[i] ^ hashKey[i]) & 0xFF);
            }
        } else {
            out.write(new byte[20]);
        }
        // 5. encrypted_index_size
        long sizeKey = ((long) ks[10] << 32) | (ks[11] & 0xFFFFFFFFL);
        writeLe64(out, indexSize ^ sizeKey);
        // 6. encrypted_index_offset
        long offKey = ((long) ks[0] << 32) | (ks[1] & 0xFFFFFFFFL);
        writeLe64(out, indexOffset ^ offKey);

        // Trailing fields (v7+, v8+, v9+, v12+) — after fixed tail, NOT before.
        // NOTE: HXE.py order is: fixed tail is the LAST thing written.
        // Our calling order puts trailing fields BEFORE the fixed tail? Let's
        // re-examine. HXE.py writes:
        //   [index], [unk1 if v7], [pk/iv/hash if v8], [stem/unk2 if v9],
        //   [content_org_hash if v12], then [flag, magic, version, hash, size, offset]
        // Wait — the code snippet shows fixed tail is written LAST. We must match.
        // We've been writing fixed tail here, so trailing fields should be BEFORE this
        // call. We'll handle trailing fields by caller for inject — see below.
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------
    private static void copyRange(RandomAccessFile src, RandomAccessFile dst,
                                  long off, long len) throws IOException {
        src.seek(off);
        dst.seek(off);
        byte[] buf = new byte[64 * 1024];
        long rem = len;
        while (rem > 0) {
            int n = (int) Math.min(buf.length, rem);
            int r = src.read(buf, 0, n);
            if (r < 0) throw new IOException("EOF while copying");
            dst.write(buf, 0, r);
            rem -= r;
        }
    }
    private static byte[] readAll(File f) throws IOException {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[64 * 1024];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            return out.toByteArray();
        }
    }
    private static byte[] padZeros(byte[] data, int target) {
        if (data.length >= target) return data;
        byte[] out = new byte[target];
        System.arraycopy(data, 0, out, 0, data.length);
        return out;
    }
    private static List<byte[]> chunk(byte[] src, int cs) {
        List<byte[]> out = new ArrayList<>();
        for (int i = 0; i < src.length; i += cs) {
            int e = Math.min(i + cs, src.length);
            byte[] c = new byte[e - i];
            System.arraycopy(src, i, c, 0, c.length);
            out.add(c);
        }
        if (out.isEmpty()) out.add(new byte[0]);
        return out;
    }
    private static byte[] compress(byte[] chunk, int cm, int level) {
        if (cm == PakConstants.CM_ZLIB) {
            java.util.zip.Deflater def = new java.util.zip.Deflater(9);
            def.setInput(chunk); def.finish();
            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            while (!def.finished()) baos.write(buf, 0, def.deflate(buf));
            def.end();
            return baos.toByteArray();
        }
        if (cm == PakConstants.CM_ZSTD || cm == PakConstants.CM_ZSTD_DICT) {
            int[] levels = {level > 0 ? level : 22, 22, 19, 16, 13, 10, 7, 4, 1};
            for (int lvl : levels) {
                try {
                    long bound = Zstd.compressBound(chunk.length);
                    byte[] out = new byte[(int) bound];
                    long written = Zstd.compress(out, chunk, lvl);
                    if (Zstd.isError(written)) continue;
                    byte[] trimmed = new byte[(int) written];
                    System.arraycopy(out, 0, trimmed, 0, (int) written);
                    return trimmed;
                } catch (Throwable ignored) {}
            }
        }
        return chunk;
    }
    private static byte[] sha1(byte[] d) {
        try { return MessageDigest.getInstance("SHA-1").digest(d); }
        catch (Exception e) { throw new RuntimeException(e); }
    }
    private static void writeLe32(java.io.RandomAccessFile out, long v) throws IOException {
        for (int i = 0; i < 4; i++) out.write((int) ((v >>> (8 * i)) & 0xFF));
    }
    private static void writeLe64(java.io.RandomAccessFile out, long v) throws IOException {
        for (int i = 0; i < 8; i++) out.write((int) ((v >>> (8 * i)) & 0xFF));
    }
    private static byte[] le5Ints(int a, int b, int c, int d, int e) {
        java.nio.ByteBuffer bb = java.nio.ByteBuffer.allocate(20)
                .order(java.nio.ByteOrder.LITTLE_ENDIAN);
        bb.putInt(a).putInt(b).putInt(c).putInt(d).putInt(e);
        return bb.array();
    }

    // ---------------------------------------------------------------
    // WorkItem
    // ---------------------------------------------------------------
    private static final class WorkItem {
        String dirStr;
        String fileName;
        String internalPath;
        byte[] plain;
        int compMethod;
        int encMethod;
        boolean encrypted;
        int blockSize;
        int compLevel;
    }
}