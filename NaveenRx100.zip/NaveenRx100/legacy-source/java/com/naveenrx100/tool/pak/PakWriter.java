/*
 * NaveenRx100 Tool - PakWriter
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.pak;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * Streaming PAK writer.
 *
 * <p>Writes to a temp file in the same directory as the final output, then
 * atomically renames on {@link #commit()}. On {@link #close()} without commit
 * the temp file is deleted.</p>
 *
 * <p>Cursor position is tracked so callers can compute file offsets (as
 * required when building the PAK index). All multi-byte writes are
 * little-endian to match the PC PAK format used by HXE.py.</p>
 */
public final class PakWriter implements Closeable {

    private static final int COPY_BUFFER_SIZE = 64 * 1024;

    private final File finalTarget;
    private final File tempFile;
    private final OutputStream out;
    private final RandomAccessFile sourceRaf; // nullable, for streaming copy
    private long cursor;
    private boolean committed;
    private boolean closed;

    public PakWriter(File finalTarget, RandomAccessFile sourceRaf) throws IOException {
        this.finalTarget = finalTarget;
        this.sourceRaf = sourceRaf;

        File parent = finalTarget.getAbsoluteFile().getParentFile();
        if (parent != null && !parent.exists()) {
            //noinspection ResultOfMethodCallIgnored
            parent.mkdirs();
        }
        String baseName = finalTarget.getName();
        this.tempFile = File.createTempFile("nxp_" + baseName + "_", ".tmp", parent);
        FileOutputStream fos = new FileOutputStream(tempFile);
        this.out = new BufferedOutputStream(fos, 256 * 1024);
        this.cursor = 0L;
    }

    // ---------------------------------------------------------------
    // Position / state
    // ---------------------------------------------------------------

    public long position() {
        return cursor;
    }

    public File getTempFile() {
        return tempFile;
    }

    // ---------------------------------------------------------------
    // Primitive writers (all little-endian)
    // ---------------------------------------------------------------

    public void writeByte(int v) throws IOException {
        out.write(v & 0xFF);
        cursor += 1;
    }

    public void writeBytes(byte[] data) throws IOException {
        if (data == null || data.length == 0) return;
        out.write(data);
        cursor += data.length;
    }

    public void writeBytes(byte[] data, int off, int len) throws IOException {
        if (len <= 0) return;
        out.write(data, off, len);
        cursor += len;
    }

    public void writeUint16LE(int v) throws IOException {
        byte[] b = new byte[2];
        b[0] = (byte) (v & 0xFF);
        b[1] = (byte) ((v >>> 8) & 0xFF);
        writeBytes(b);
    }

    public void writeUint32LE(long v) throws IOException {
        byte[] b = new byte[4];
        b[0] = (byte) (v & 0xFF);
        b[1] = (byte) ((v >>> 8) & 0xFF);
        b[2] = (byte) ((v >>> 16) & 0xFF);
        b[3] = (byte) ((v >>> 24) & 0xFF);
        writeBytes(b);
    }

    public void writeInt32LE(int v) throws IOException {
        writeUint32LE(v & 0xFFFFFFFFL);
    }

    public void writeUint64LE(long v) throws IOException {
        byte[] b = new byte[8];
        for (int i = 0; i < 8; i++) {
            b[i] = (byte) ((v >>> (8 * i)) & 0xFF);
        }
        writeBytes(b);
    }

    /** Writes an integer as the 4-byte little-endian used by PAK string length prefixes. */
    public void writeLength(int len) throws IOException {
        writeInt32LE(len);
    }

    // ---------------------------------------------------------------
    // PAK string writer (int32 length prefix + bytes + null terminator)
    // Matches HXE.py _pw_string():
    //     if not s: return struct.pack('<i', 0)
    //     b = s.encode('utf-8') + b'\x00'
    //     return struct.pack('<i', len(b)) + b
    // ---------------------------------------------------------------

    public void writeString(String s) throws IOException {
        if (s == null || s.isEmpty()) {
            writeInt32LE(0);
            return;
        }
        byte[] u = s.getBytes(StandardCharsets.UTF_8);
        byte[] withNul = new byte[u.length + 1];
        System.arraycopy(u, 0, withNul, 0, u.length);
        withNul[u.length] = 0;
        writeInt32LE(withNul.length);
        writeBytes(withNul);
    }

    // ---------------------------------------------------------------
    // Streaming copy from source RandomAccessFile
    // ---------------------------------------------------------------

    /**
     * Copies {@code length} bytes from the source RandomAccessFile at
     * {@code sourceOffset} to the output stream. Uses a bounded buffer so
     * arbitrarily large PAK entries can be copied without loading into RAM.
     */
    public void copyFromSource(long sourceOffset, long length) throws IOException {
        if (sourceRaf == null) {
            throw new IOException("No source RandomAccessFile supplied to PakWriter");
        }
        if (length <= 0) return;

        sourceRaf.seek(sourceOffset);
        byte[] buf = new byte[COPY_BUFFER_SIZE];
        long remaining = length;
        while (remaining > 0) {
            int want = (int) Math.min(buf.length, remaining);
            int read = sourceRaf.read(buf, 0, want);
            if (read < 0) {
                throw new IOException("Unexpected EOF while copying source; wanted "
                        + remaining + " more bytes");
            }
            out.write(buf, 0, read);
            cursor += read;
            remaining -= read;
        }
    }

    // ---------------------------------------------------------------
    // Patch primitive — used for back-patching SHA1 in unchanged blocks
    // ---------------------------------------------------------------

    /**
     * Returns a 64KB buffer suitable for hashing an already-written region
     * after the writer has been flushed. Caller is responsible for
     * flushing first.
     */
    public byte[] readBack(long offset, int length) throws IOException {
        flush();
        try (RandomAccessFile raf = new RandomAccessFile(tempFile, "r")) {
            byte[] buf = new byte[length];
            raf.seek(offset);
            int total = 0;
            while (total < length) {
                int r = raf.read(buf, total, length - total);
                if (r < 0) break;
                total += r;
            }
            if (total < length) {
                byte[] trimmed = new byte[total];
                System.arraycopy(buf, 0, trimmed, 0, total);
                return trimmed;
            }
            return buf;
        }
    }

    // ---------------------------------------------------------------
    // Commit / close / abort
    // ---------------------------------------------------------------

    public void flush() throws IOException {
        out.flush();
    }

    /**
     * Flushes, closes the output stream and atomically renames the temp file
     * to the final target. Any existing final file is deleted first.
     */
    public void commit() throws IOException {
        if (closed) throw new IOException("PakWriter already closed");
        out.flush();
        out.close();
        closed = true;

        if (finalTarget.exists()) {
            //noinspection ResultOfMethodCallIgnored
            finalTarget.delete();
        }
        if (!tempFile.renameTo(finalTarget)) {
            throw new IOException("Failed to rename temp file " + tempFile
                    + " to " + finalTarget);
        }
        committed = true;
    }

    @Override
    public void close() throws IOException {
        if (!closed) {
            try {
                out.close();
            } catch (IOException ignored) {
                // ignore
            }
            closed = true;
        }
        if (!committed && tempFile.exists()) {
            //noinspection ResultOfMethodCallIgnored
            tempFile.delete();
        }
    }
}