/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.File;
import java.io.IOException;
import java.util.Map;

/** Read-only extraction entry points for PAK files. */
public final class PakUnpacker {
    private PakUnpacker() {}

    public static void unpackAll(File pakFile, File outputDir, ProgressCallback callback) throws IOException {
        try (TencentPakFile pak = new TencentPakFile(pakFile, false)) {
            pak.dump(outputDir, callback);
        } catch (IOException e) {
            if (callback != null) callback.onError(e.getMessage(), e);
            throw e;
        } catch (RuntimeException e) {
            if (callback != null) callback.onError(e.getMessage(), e);
            throw e;
        }
    }

    public static void unpackFile(File pakFile, String internalPath, File outputFile) throws IOException {
        if (internalPath == null) throw new IllegalArgumentException("internal path required");
        String normalized = internalPath.replace('\\', '/');
        while (normalized.startsWith("/")) normalized = normalized.substring(1);
        try (TencentPakFile pak = new TencentPakFile(pakFile, false)) {
            String mount = pak.getMountPoint();
            if (!mount.isEmpty() && (normalized.equals(mount) || normalized.startsWith(mount + "/"))) {
                normalized = normalized.equals(mount) ? "" : normalized.substring(mount.length() + 1);
            }
            String[] parts = normalized.split("/");
            if (normalized.isEmpty() || parts.length < 1) throw new IOException("Empty internal path");
            String fileName = parts[parts.length - 1];
            StringBuilder parent = new StringBuilder();
            for (int i = 0; i < parts.length - 1; i++) {
                if (i > 0) parent.append('/');
                parent.append(parts[i]);
            }
            TencentPakEntry entry = null;
            for (Map.Entry<String, Map<String, TencentPakEntry>> directory : pak.getIndex().entrySet()) {
                if (directory.getKey().equals(parent.toString())) {
                    entry = directory.getValue().get(fileName);
                    if (entry != null) break;
                }
            }
            if (entry == null) throw new IOException("Internal file not found in PAK: " + internalPath);
            pak.writeToDisk(outputFile, entry);
        }
    }
}
