/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.math.BigInteger;
import java.util.Arrays;

/** RSA public exponent extraction and HXE.py's meowmeow/hashhash/xorxor transform. */
public final class RSACrypto {
    private static final BigInteger E = BigInteger.valueOf(65537L);
    private RSACrypto() {}
    private static byte[] reverse(byte[] in) { byte[] out=in.clone(); for(int i=0,j=out.length-1;i<j;i++,j--){byte t=out[i];out[i]=out[j];out[j]=t;} return out; }
    private static BigInteger littleEndianInteger(byte[] bytes) { return new BigInteger(1, reverse(bytes)); }
    private static byte[] fixedLittleEndian(BigInteger value, int length) {
        byte[] be=value.toByteArray(); if(be.length>1 && be[0]==0) be=Arrays.copyOfRange(be,1,be.length);
        byte[] out=new byte[length]; int count=Math.min(length,be.length);
        for(int i=0;i<count;i++) out[i]=be[be.length-1-i]; return out;
    }
    public static byte[] rsaExtract(byte[] signature, byte[] modulus) {
        if(signature==null||modulus==null||signature.length==0||modulus.length==0) throw new IllegalArgumentException("signature and modulus are required");
        BigInteger n=littleEndianInteger(modulus), c=littleEndianInteger(signature);
        if(n.signum()==0) throw new IllegalArgumentException("RSA modulus cannot be zero");
        byte[] m=fixedLittleEndian(c.modPow(E,n),256);
        int len=m.length; while(len>0 && m[len-1]==0) len--;
        byte[] trimmed=Arrays.copyOf(m,len); int rem=trimmed.length%4;
        if(rem!=0) trimmed=Arrays.copyOf(trimmed,trimmed.length+(4-rem));
        return meowmeow(trimmed);
    }
    public static byte[] rsa_extract(byte[] signature, byte[] modulus) { return rsaExtract(signature,modulus); }
    public static byte[] hashhash(byte[] buffer, int n) {
        if(buffer==null||n<0) throw new IllegalArgumentException("invalid hashhash input");
        byte[] digest=SHA1Hasher.hash(buffer), out=new byte[n];
        for(int i=0;i<n;i++) out[i]=digest[i%digest.length];
        return out;
    }
    public static byte[] _hashhash(byte[] buffer,int n){return hashhash(buffer,n);}
    public static byte[] xorxor(byte[] buffer, byte[] x) {
        if(buffer==null||x==null||x.length==0) throw new IllegalArgumentException("xor key must not be empty");
        byte[] out=new byte[buffer.length]; for(int i=0;i<buffer.length;i++)out[i]=(byte)(buffer[i]^x[i%x.length]); return out;
    }
    public static byte[] _xorxor(byte[] buffer,byte[] x){return xorxor(buffer,x);}
    public static byte[] meowmeow(byte[] buffer) {
        if(buffer==null||buffer.length<43) return new byte[0];
        byte[] x1=Arrays.copyOfRange(buffer,1,Math.min(buffer.length,21));
        byte[] x2=Arrays.copyOfRange(buffer,21,buffer.length);
        x1=xorxor(x1,hashhash(x2,x1.length));
        x2=xorxor(x2,hashhash(x1,x2.length));
        if(x2.length<20) return new byte[0];
        byte[] part1=Arrays.copyOfRange(x2,0,20);
        if(!Arrays.equals(part1,SHA1Hasher.hash(new byte[20]))) return new byte[0];
        byte[] m=Arrays.copyOfRange(x2,20,x2.length); int first=-1;
        for(int i=0;i<m.length;i++) if(m[i]!=0){first=i;break;}
        if(first<0) return new byte[0];
        return Arrays.copyOfRange(m,first+1,m.length);
    }
    public static byte[] _meowmeow(byte[] buffer){return meowmeow(buffer);}
}
