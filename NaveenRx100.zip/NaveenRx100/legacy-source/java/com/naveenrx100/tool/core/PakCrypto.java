/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Java port of the PakCrypto class in HXE.py. Byte order and custom cipher constants follow source. */
public final class PakCrypto {
    public interface PakInfo { int getVersion(); byte[] getPackedKey(); byte[] getPackedIv(); }
    private PakCrypto() {}
    private static final byte[] SIMPLE2_KEY = Constants.SIMPLE2_DECRYPT_KEY.clone();
    public static final class LCG {
        private int state;
        public LCG(int seed){state=seed;}
        private static int wrap(long x){return (int)x;}
        public int next(){
            int x1=wrap(1103515245L*(long)state);
            state=wrap((long)x1+12345L);
            int x2=state<0?wrap((long)x1+77880L):state;
            return (int)((((long)(x2 >> 16)) & 0xFFFFFFFFL)%32767L);
        }
    }
    public static byte[] xorxor(byte[] buffer, byte[] x){return RSACrypto.xorxor(buffer,x);}
    public static byte[] hashhash(byte[] buffer,int n){return RSACrypto.hashhash(buffer,n);}
    public static byte[] meowmeow(byte[] buffer){return RSACrypto.meowmeow(buffer);}
    public static byte[] rsaExtract(byte[] signature,byte[] modulus){return RSACrypto.rsaExtract(signature,modulus);}
    public static int[] zucKeystream(){return ZUCCipher.generateWords();}
    public static int[] zuc_keystream(){return zucKeystream();}
    public static byte[] decryptSimple1(byte[] ciphertext){byte[] out=ciphertext.clone();for(int i=0;i<out.length;i++)out[i]^=(byte)Constants.SIMPLE1_DECRYPT_KEY;return out;}
    public static byte[] _decrypt_simple1(byte[] ciphertext){return decryptSimple1(ciphertext);}
    public static byte[] decryptSimple2(byte[] ciphertext){
        if(ciphertext==null||(ciphertext.length%Constants.SIMPLE2_BLOCK_SIZE)!=0) throw new IllegalArgumentException("simple2 ciphertext length must be divisible by 16");
        byte[] out=new byte[ciphertext.length]; int rolling=(int)Constants.SIMPLE2_DECRYPT_KEY_U32;
        for(int p=0;p<ciphertext.length;p+=4){int v=(ciphertext[p]&255)|((ciphertext[p+1]&255)<<8)|((ciphertext[p+2]&255)<<16)|(ciphertext[p+3]<<24); rolling^=v; out[p]=(byte)rolling;out[p+1]=(byte)(rolling>>>8);out[p+2]=(byte)(rolling>>>16);out[p+3]=(byte)(rolling>>>24);}
        return out;
    }
    public static byte[] _decrypt_simple2(byte[] ciphertext){return decryptSimple2(ciphertext);}
    public static byte[] deriveSm4Key(Path file, int method){
        if(file==null) throw new IllegalArgumentException("file path required");
        String name=file.getFileName().toString(); int dot=name.lastIndexOf('.'); String stem=dot>0?name.substring(0,dot):name;
        String secret;
        if(method==Constants.EM_SM4_2) secret=Constants.SM4_SECRET_2;
        else if(method==Constants.EM_SM4_4) secret=Constants.SM4_SECRET_4;
        else {int idx=Math.floorMod(method-Constants.EM_SM4_NEW_BASE,Constants.SM4_SECRET_NEW.length);secret=Constants.SM4_SECRET_NEW[idx]+method;}
        return Arrays.copyOf(SHA1Hasher.hash((stem.toLowerCase(java.util.Locale.ROOT)+secret).getBytes(java.nio.charset.StandardCharsets.UTF_8)),16);
    }
    public static byte[] _derive_sm4_key(Path file,int method){return deriveSm4Key(file,method);}
    public static byte[] decryptSm4(byte[] ciphertext,Path file,int method){
        if(ciphertext==null||(ciphertext.length&15)!=0) throw new IllegalArgumentException("SM4 ciphertext length must be a multiple of 16");
        SM4Cipher sm4=new SM4Cipher(deriveSm4Key(file,method)); byte[] out=new byte[ciphertext.length];
        for(int p=0;p<ciphertext.length;p+=16)System.arraycopy(sm4.decryptBlock(Arrays.copyOfRange(ciphertext,p,p+16)),0,out,p,16);
        return out;
    }
    public static byte[] _decrypt_sm4(byte[] ciphertext,Path file,int method){return decryptSm4(ciphertext,file,method);}
    public static boolean isSimple1Method(int method){return method==Constants.EM_SIMPLE1;}
    public static boolean isSimple2Method(int method){return method==Constants.EM_SIMPLE2||method==17;}
    public static boolean isSm4Method(int method){return method==Constants.EM_SM4_2||method==Constants.EM_SM4_4||(method&Constants.EM_SM4_NEW_MASK)!=0;}
    public static boolean _is_simple1_method(int method){return isSimple1Method(method);}
    public static boolean _is_simple2_method(int method){return isSimple2Method(method);}
    public static boolean _is_sm4_method(int method){return isSm4Method(method);}
    public static int alignEncryptedContentSize(int n,int method){if(n<0)throw new IllegalArgumentException("size must be non-negative");int a=isSimple2Method(method)?Constants.SIMPLE2_BLOCK_SIZE:(isSm4Method(method)?16:1);return ((n+a-1)/a)*a;}
    public static int align_encrypted_content_size(int n,int method){return alignEncryptedContentSize(n,method);}
    public static byte[] decryptBlock(byte[] ciphertext,Path file,int method){
        if(ciphertext==null)throw new IllegalArgumentException("ciphertext required");
        if(isSimple1Method(method))return decryptSimple1(ciphertext);
        if(isSimple2Method(method))return decryptSimple2(ciphertext);
        if(isSm4Method(method))return decryptSm4(ciphertext,file,method);
        return ciphertext.clone();
    }
    public static byte[] decrypt_block(byte[] ciphertext,Path file,int method){return decryptBlock(ciphertext,file,method);}
    public static int[] generateBlockIndices(int n,int method){
        if(n<0)throw new IllegalArgumentException("n must be non-negative");
        if(!isSm4Method(method)){int[] a=new int[n];for(int i=0;i<n;i++)a[i]=i;return a;}
        int[] permutation=new int[n];boolean[] used=new boolean[n];LCG lcg=new LCG(n);int count=0;
        while(count<n){int x=lcg.next()%n;if(!used[x]){used[x]=true;permutation[count++]=x;}}
        int[] inverse=new int[n];for(int i=0;i<n;i++)inverse[permutation[i]]=i;return inverse;
    }
    public static int[] generate_block_indices(int n,int method){return generateBlockIndices(n,method);}
    public static byte[] decryptIndex(byte[] ciphertext,PakInfo info){if(info==null)throw new IllegalArgumentException("pak info required");return decryptIndex(ciphertext,info.getVersion(),info.getPackedKey(),info.getPackedIv());}
    public static byte[] decrypt_index(byte[] ciphertext,PakInfo info){return decryptIndex(ciphertext,info);}
    public static byte[] decryptIndex(byte[] ciphertext,int version,byte[] packedKey,byte[] packedIv){
        if(ciphertext==null)throw new IllegalArgumentException("ciphertext required");
        if(version>7){
            try {
                byte[] key=RSACrypto.rsaExtract(packedKey,Constants.RSA_MOD_1), iv=RSACrypto.rsaExtract(packedIv,Constants.RSA_MOD_1);
                if(key.length==32&&iv.length>=16)return AESCipher.decryptPkcs7OrRaw(ciphertext,key,Arrays.copyOf(iv,16));
            } catch(Exception ignored) { /* HXE.py falls back to ZUC on any extraction/AES error. */ }
            int[] words=ZUCCipher.generateWords(Constants.ZUC_KEY,Constants.ZUC_IV,16);
            byte[] ks=new byte[20]; for(int i=0;i<5;i++){int v=words[i+4],p=i*4;ks[p]=(byte)v;ks[p+1]=(byte)(v>>>8);ks[p+2]=(byte)(v>>>16);ks[p+3]=(byte)(v>>>24);}
            byte[] out=new byte[ciphertext.length];for(int i=0;i<out.length;i++)out[i]=(byte)(ciphertext[i]^ks[i%ks.length]);return out;
        }
        return decryptSimple1(ciphertext);
    }
}
