/*
 * NaveenRx100 Tool - Generic Archive Repacker
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis, archive writing, and
 * cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Repack operations for the documented NPAK v1 learning format only. */
public final class PakRepacker {
    private PakRepacker(){}
    public static final class Archive implements Closeable {
        public final File file; public final PakFooterWriter.Footer footer; public final List<PakIndexWriter.Entry> entries;
        Archive(File f,PakFooterWriter.Footer ft,List<PakIndexWriter.Entry> es){file=f;footer=ft;entries=Collections.unmodifiableList(es);}
        @Override public void close(){}
    }
    public static Archive open(File file)throws IOException{return open(file,null);}
    public static Archive open(File file,byte[] indexKey)throws IOException{
        if(file==null||!file.isFile())throw new IOException("Archive not found: "+file);try(RandomAccessFile raf=new RandomAccessFile(file,"r")){
            PakFooterWriter.Footer ft=PakFooterWriter.parse(raf);byte[] index=readRange(raf,ft.indexOffset,ft.indexLength);
            if((ft.flags&PakFooterWriter.FLAG_INDEX_ENCRYPTED)!=0){if(indexKey==null)throw new IOException("Index is encrypted; key required");try{index=PakEncryptor.decryptBytes(index,indexKey);}catch(Exception e){throw new IOException("Cannot decrypt index",e);}}
            PakFooterWriter.verifyIndex(index,ft);List<PakIndexWriter.Entry> es=PakIndexWriter.parse(index);long dataEnd=ft.indexOffset;
            for(PakIndexWriter.Entry e:es)if(e.offset<8||e.storedSize<0||e.offset>dataEnd||e.storedSize>dataEnd-e.offset)throw new IOException("Entry range outside data section: "+e.path);
            return new Archive(file,ft,new ArrayList<>(es));
        }
    }
    public static int repack(File source,File editedRoot,File output,boolean forceAdd,ProgressCallback cb,AtomicBoolean cancel,File cacheDir)throws IOException{
        return repack(source,editedRoot,output,null,forceAdd,null,cb,cancel,cacheDir);
    }
    public static int repack(File source,File editedRoot,File output,String targetPath,boolean forceAdd,Map<String,String> pathMap,ProgressCallback cb,AtomicBoolean cancel,File cacheDir)throws IOException{
        Archive a=open(source);Map<String,PakIndexWriter.Entry> old=new LinkedHashMap<>();for(PakIndexWriter.Entry e:a.entries)old.put(e.path.toLowerCase(Locale.ROOT),e);
        Map<String,File> scanned=scan(editedRoot);Map<String,File> edits=new LinkedHashMap<>();Map<String,String> displayPaths=new LinkedHashMap<>();for(Map.Entry<String,File> x:scanned.entrySet()){String destination=x.getKey();if(pathMap!=null&&pathMap.containsKey(destination))destination=pathMap.get(destination);else if(targetPath!=null&&!targetPath.trim().isEmpty())destination=targetPath.replace('\\','/')+"/"+destination;destination=PakIndexWriter.normalizePath(destination);String key=destination.toLowerCase(Locale.ROOT);if(edits.put(key,x.getValue())!=null)throw new IOException("Two edited files map to the same destination: "+destination);displayPaths.put(key,destination);}
        Map<String,File> matched=new LinkedHashMap<>();for(Map.Entry<String,File> x:edits.entrySet()){String key=x.getKey();if(old.containsKey(key)||forceAdd)matched.put(key,x.getValue());}
        File temp=PakWriter.createTemp(cacheDir,"npak-repack-");int total=a.entries.size()+Math.max(0,matched.size()-countExisting(matched,old));int done=0;
        try(PakWriter w=PakWriter.open(temp);RandomAccessFile src=new RandomAccessFile(source,"r")){
            w.writeBytes(new byte[]{'N','P','A','K',1,0,0,0});List<PakIndexWriter.Entry> out=new ArrayList<>();Set<String> consumed=new HashSet<>();byte[] buf=new byte[PakWriter.BUFFER_SIZE];
            for(PakIndexWriter.Entry e:a.entries){check(cancel);File replacement=matched.get(e.path.toLowerCase(Locale.ROOT));long offset=w.position();if(replacement!=null){copyFile(replacement,w,cancel);consumed.add(e.path.toLowerCase(Locale.ROOT));out.add(new PakIndexWriter.Entry(e.path,offset,replacement.length(),replacement.length(),false,hashFile(replacement,cancel)));}else{copyRange(src,e.offset,e.storedSize,w,cancel);out.add(new PakIndexWriter.Entry(e.path,offset,e.storedSize,e.originalSize,e.encrypted,e.sha256));}done++;progress(cb,done,total,"Repacking "+e.path);}
            for(Map.Entry<String,File> x:matched.entrySet()){if(consumed.contains(x.getKey())||old.containsKey(x.getKey()))continue;check(cancel);File f=x.getValue();String rel=displayPaths.get(x.getKey());long off=w.position();copyFile(f,w,cancel);out.add(new PakIndexWriter.Entry(rel,off,f.length(),f.length(),false,hashFile(f,cancel)));done++;progress(cb,done,total,"Adding "+rel);}
            byte[] index=PakIndexWriter.serialize(out);long idxOff=w.position();w.writeBytes(index);w.writeBytes(PakFooterWriter.serialize(idxOff,index.length,index,false));w.flush();PakWriter.atomicReplace(temp,output);if(cb!=null)cb.onComplete("Repacked "+out.size()+" entries to "+output.getAbsolutePath());return done;
        }catch(Throwable t){temp.delete();if(t instanceof IOException)throw(IOException)t;if(t instanceof RuntimeException)throw(RuntimeException)t;throw new IOException("Repack failed",t);}finally{if(temp.exists())temp.delete();}
    }
    public static int repack(File source,File editedRoot,File output,boolean forceAdd,ProgressCallback cb)throws IOException{return repack(source,editedRoot,output,forceAdd,cb,new AtomicBoolean(false),output.getAbsoluteFile().getParentFile());}
    static Map<String,File> scan(File root)throws IOException{if(root==null||!root.isDirectory())throw new IOException("Edit directory does not exist: "+root);Map<String,File> out=new TreeMap<>();scanRec(root,root,out);return out;}
    private static void scanRec(File root,File dir,Map<String,File> out)throws IOException{File[] fs=dir.listFiles();if(fs==null)throw new IOException("Cannot list directory: "+dir);Arrays.sort(fs,Comparator.comparing(File::getName,String.CASE_INSENSITIVE_ORDER));for(File f:fs){if(f.isDirectory())scanRec(root,f,out);else if(f.isFile()){String rel=relative(root,f);if(out.put(rel,f)!=null)throw new IOException("Duplicate path: "+rel);}}}
    static String relative(File root,File f)throws IOException{String r=root.getCanonicalFile().toURI().relativize(f.getCanonicalFile().toURI()).getPath();if(r.isEmpty()||r.startsWith("../")||r.startsWith("/"))throw new IOException("File outside edit root");return PakIndexWriter.normalizePath(r);}
    static byte[] readRange(RandomAccessFile raf,long offset,long length)throws IOException{if(length>Integer.MAX_VALUE)throw new IOException("Index too large to parse safely");byte[] b=new byte[(int)length];raf.seek(offset);raf.readFully(b);return b;}
    static void copyRange(RandomAccessFile in,long off,long len,PakWriter out,AtomicBoolean cancel)throws IOException{in.seek(off);byte[] b=new byte[PakWriter.BUFFER_SIZE];long done=0;while(done<len){check(cancel);int want=(int)Math.min(b.length,len-done);int n=in.read(b,0,want);if(n<0)throw new EOFException("Archive truncated during copy");byte[] chunk=n==b.length?b:Arrays.copyOf(b,n);out.writeBytes(chunk);done+=n;}}
    static void copyFile(File f,PakWriter out,AtomicBoolean cancel)throws IOException{try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[PakWriter.BUFFER_SIZE];int n;while((n=in.read(b))!=-1){check(cancel);out.writeBytes(n==b.length?b:Arrays.copyOf(b,n));}}}
    static byte[] hashFile(File f,AtomicBoolean cancel)throws IOException{try{java.security.MessageDigest d=java.security.MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[] b=new byte[PakWriter.BUFFER_SIZE];int n;while((n=in.read(b))!=-1){check(cancel);d.update(b,0,n);}}return d.digest();}catch(java.security.NoSuchAlgorithmException e){throw new IOException(e);}}
    static void check(AtomicBoolean c)throws IOException{if(c!=null&&c.get())throw new IOException("Operation cancelled");}
    static void progress(ProgressCallback cb,int d,int t,String msg){if(cb!=null)cb.onProgress(d,t,msg);}
    private static int countExisting(Map<String,File> m,Map<String,PakIndexWriter.Entry> old){int n=0;for(String k:m.keySet())if(old.containsKey(k))n++;return n;}
}
