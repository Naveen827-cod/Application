/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

/** Constants extracted from HXE.py. Arrays are exposed as arrays for convenient binary processing. */
public final class Constants {
    private Constants() {}

    public static final byte[] STRING_XOR_KEY = new byte[] {(byte) 0x11, (byte) 0x21, (byte) 0x36, (byte) 0x47, (byte) 0x46, (byte) 0x57, (byte) 0xA7, (byte) 0x8D, (byte) 0x9D, (byte) 0x84, (byte) 0x90, (byte) 0xD8, (byte) 0xAB, (byte) 0x00, (byte) 0x8C, (byte) 0x35, (byte) 0x26, (byte) 0x1A, (byte) 0xF7, (byte) 0xE4, (byte) 0x58, (byte) 0x05, (byte) 0xB8, (byte) 0xB3, (byte) 0x15, (byte) 0x07, (byte) 0xD0, (byte) 0x2C, (byte) 0x1E, (byte) 0x8F, (byte) 0xF6, (byte) 0xC8};
    public static final int[] BGMI_TO_STD = new int[] {13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63};
    public static final int[] STD_TO_BGMI = buildStdToBgmi();
    public static final int[] STD_FMT = new int[] {0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 2, 0, 1, 0, 3};

    public static final int iABC = 0;
    public static final int iABx = 1;
    public static final int iAsBx = 2;
    public static final int iAx = 3;
    public static final int HEADER_SIZE = 33;

    public static final byte[] ZUC_KEY = new byte[] {(byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01};
    public static final byte[] ZUC_IV = new byte[] {(byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF};
    public static final String RSA_MOD_1_HEX = "CBE8B9F2504050EF9831B719E9A6249A6D238505ADE909BDE78C180DED6072A0C3347B8AF4780E1F212D952D82D4BF7F233C1ECA499E1F9D9A85B4FAD759F54BABC1666C5DE411EA9E4B2374425DD6C6F54333BBC8F2610FE6063E4D0D6C21A671A8F7C3740555E5DC06D4E1691C456DB4116C0C012BF7B206E8311AAAEC689952BF804EF638F09D5822B4117B114208F14DEB459E80CB770E5B0D7978E21F5E6CED4999D3583108221A7AB28B960277ADB5690A332784019D9C195BE4EA9EA0A09459010F236465DE0D59C3EF7324E954E1118D93EE19F299760C2CDB963CE87973EA5ECC9BBE81C27D4C7C8572AC07E9BCEAC9BD72AB7A56A3C0AD736ABCE4";
    public static final String RSA_MOD_2_HEX = "7F58E8A39A4DA4E87357DDD650EAA16D3B5CE95B213D1030A662566444796A78A84AE9AC3DBFFDE7F41094896696835DAF13B89E6EC2B84963B1B1BAF7151DA245C3FBFAE2A6AE18B2684D03F9229DE2C91440F2A3A3BCDE1E5680C16722A88039C73560D5D43F4B6562C2EEA5B1D926D86B51108A2643C70FB74D6442CE3A08339B8FD8F660AE88129B7AB8C46F2FA58124485CCCB1E987B05A6DA65A01858ED3F89905449AE42BB07290FCB9994BF22E26610BCABB9804783A3B9587917F3D97316EDDA15C5E13F79066407B55A93B291B68A4AC42A98D6E35FED84B14A792D154E62028DDAD20FC301951E5924BE9AD62FB719DD94CC30CAB871BEC4377A8";
    public static final byte[] RSA_MOD_1 = new byte[] {(byte) 0xCB, (byte) 0xE8, (byte) 0xB9, (byte) 0xF2, (byte) 0x50, (byte) 0x40, (byte) 0x50, (byte) 0xEF, (byte) 0x98, (byte) 0x31, (byte) 0xB7, (byte) 0x19, (byte) 0xE9, (byte) 0xA6, (byte) 0x24, (byte) 0x9A, (byte) 0x6D, (byte) 0x23, (byte) 0x85, (byte) 0x05, (byte) 0xAD, (byte) 0xE9, (byte) 0x09, (byte) 0xBD, (byte) 0xE7, (byte) 0x8C, (byte) 0x18, (byte) 0x0D, (byte) 0xED, (byte) 0x60, (byte) 0x72, (byte) 0xA0, (byte) 0xC3, (byte) 0x34, (byte) 0x7B, (byte) 0x8A, (byte) 0xF4, (byte) 0x78, (byte) 0x0E, (byte) 0x1F, (byte) 0x21, (byte) 0x2D, (byte) 0x95, (byte) 0x2D, (byte) 0x82, (byte) 0xD4, (byte) 0xBF, (byte) 0x7F, (byte) 0x23, (byte) 0x3C, (byte) 0x1E, (byte) 0xCA, (byte) 0x49, (byte) 0x9E, (byte) 0x1F, (byte) 0x9D, (byte) 0x9A, (byte) 0x85, (byte) 0xB4, (byte) 0xFA, (byte) 0xD7, (byte) 0x59, (byte) 0xF5, (byte) 0x4B, (byte) 0xAB, (byte) 0xC1, (byte) 0x66, (byte) 0x6C, (byte) 0x5D, (byte) 0xE4, (byte) 0x11, (byte) 0xEA, (byte) 0x9E, (byte) 0x4B, (byte) 0x23, (byte) 0x74, (byte) 0x42, (byte) 0x5D, (byte) 0xD6, (byte) 0xC6, (byte) 0xF5, (byte) 0x43, (byte) 0x33, (byte) 0xBB, (byte) 0xC8, (byte) 0xF2, (byte) 0x61, (byte) 0x0F, (byte) 0xE6, (byte) 0x06, (byte) 0x3E, (byte) 0x4D, (byte) 0x0D, (byte) 0x6C, (byte) 0x21, (byte) 0xA6, (byte) 0x71, (byte) 0xA8, (byte) 0xF7, (byte) 0xC3, (byte) 0x74, (byte) 0x05, (byte) 0x55, (byte) 0xE5, (byte) 0xDC, (byte) 0x06, (byte) 0xD4, (byte) 0xE1, (byte) 0x69, (byte) 0x1C, (byte) 0x45, (byte) 0x6D, (byte) 0xB4, (byte) 0x11, (byte) 0x6C, (byte) 0x0C, (byte) 0x01, (byte) 0x2B, (byte) 0xF7, (byte) 0xB2, (byte) 0x06, (byte) 0xE8, (byte) 0x31, (byte) 0x1A, (byte) 0xAA, (byte) 0xEC, (byte) 0x68, (byte) 0x99, (byte) 0x52, (byte) 0xBF, (byte) 0x80, (byte) 0x4E, (byte) 0xF6, (byte) 0x38, (byte) 0xF0, (byte) 0x9D, (byte) 0x58, (byte) 0x22, (byte) 0xB4, (byte) 0x11, (byte) 0x7B, (byte) 0x11, (byte) 0x42, (byte) 0x08, (byte) 0xF1, (byte) 0x4D, (byte) 0xEB, (byte) 0x45, (byte) 0x9E, (byte) 0x80, (byte) 0xCB, (byte) 0x77, (byte) 0x0E, (byte) 0x5B, (byte) 0x0D, (byte) 0x79, (byte) 0x78, (byte) 0xE2, (byte) 0x1F, (byte) 0x5E, (byte) 0x6C, (byte) 0xED, (byte) 0x49, (byte) 0x99, (byte) 0xD3, (byte) 0x58, (byte) 0x31, (byte) 0x08, (byte) 0x22, (byte) 0x1A, (byte) 0x7A, (byte) 0xB2, (byte) 0x8B, (byte) 0x96, (byte) 0x02, (byte) 0x77, (byte) 0xAD, (byte) 0xB5, (byte) 0x69, (byte) 0x0A, (byte) 0x33, (byte) 0x27, (byte) 0x84, (byte) 0x01, (byte) 0x9D, (byte) 0x9C, (byte) 0x19, (byte) 0x5B, (byte) 0xE4, (byte) 0xEA, (byte) 0x9E, (byte) 0xA0, (byte) 0xA0, (byte) 0x94, (byte) 0x59, (byte) 0x01, (byte) 0x0F, (byte) 0x23, (byte) 0x64, (byte) 0x65, (byte) 0xDE, (byte) 0x0D, (byte) 0x59, (byte) 0xC3, (byte) 0xEF, (byte) 0x73, (byte) 0x24, (byte) 0xE9, (byte) 0x54, (byte) 0xE1, (byte) 0x11, (byte) 0x8D, (byte) 0x93, (byte) 0xEE, (byte) 0x19, (byte) 0xF2, (byte) 0x99, (byte) 0x76, (byte) 0x0C, (byte) 0x2C, (byte) 0xDB, (byte) 0x96, (byte) 0x3C, (byte) 0xE8, (byte) 0x79, (byte) 0x73, (byte) 0xEA, (byte) 0x5E, (byte) 0xCC, (byte) 0x9B, (byte) 0xBE, (byte) 0x81, (byte) 0xC2, (byte) 0x7D, (byte) 0x4C, (byte) 0x7C, (byte) 0x85, (byte) 0x72, (byte) 0xAC, (byte) 0x07, (byte) 0xE9, (byte) 0xBC, (byte) 0xEA, (byte) 0xC9, (byte) 0xBD, (byte) 0x72, (byte) 0xAB, (byte) 0x7A, (byte) 0x56, (byte) 0xA3, (byte) 0xC0, (byte) 0xAD, (byte) 0x73, (byte) 0x6A, (byte) 0xBC, (byte) 0xE4};
    public static final byte[] RSA_MOD_2 = new byte[] {(byte) 0x7F, (byte) 0x58, (byte) 0xE8, (byte) 0xA3, (byte) 0x9A, (byte) 0x4D, (byte) 0xA4, (byte) 0xE8, (byte) 0x73, (byte) 0x57, (byte) 0xDD, (byte) 0xD6, (byte) 0x50, (byte) 0xEA, (byte) 0xA1, (byte) 0x6D, (byte) 0x3B, (byte) 0x5C, (byte) 0xE9, (byte) 0x5B, (byte) 0x21, (byte) 0x3D, (byte) 0x10, (byte) 0x30, (byte) 0xA6, (byte) 0x62, (byte) 0x56, (byte) 0x64, (byte) 0x44, (byte) 0x79, (byte) 0x6A, (byte) 0x78, (byte) 0xA8, (byte) 0x4A, (byte) 0xE9, (byte) 0xAC, (byte) 0x3D, (byte) 0xBF, (byte) 0xFD, (byte) 0xE7, (byte) 0xF4, (byte) 0x10, (byte) 0x94, (byte) 0x89, (byte) 0x66, (byte) 0x96, (byte) 0x83, (byte) 0x5D, (byte) 0xAF, (byte) 0x13, (byte) 0xB8, (byte) 0x9E, (byte) 0x6E, (byte) 0xC2, (byte) 0xB8, (byte) 0x49, (byte) 0x63, (byte) 0xB1, (byte) 0xB1, (byte) 0xBA, (byte) 0xF7, (byte) 0x15, (byte) 0x1D, (byte) 0xA2, (byte) 0x45, (byte) 0xC3, (byte) 0xFB, (byte) 0xFA, (byte) 0xE2, (byte) 0xA6, (byte) 0xAE, (byte) 0x18, (byte) 0xB2, (byte) 0x68, (byte) 0x4D, (byte) 0x03, (byte) 0xF9, (byte) 0x22, (byte) 0x9D, (byte) 0xE2, (byte) 0xC9, (byte) 0x14, (byte) 0x40, (byte) 0xF2, (byte) 0xA3, (byte) 0xA3, (byte) 0xBC, (byte) 0xDE, (byte) 0x1E, (byte) 0x56, (byte) 0x80, (byte) 0xC1, (byte) 0x67, (byte) 0x22, (byte) 0xA8, (byte) 0x80, (byte) 0x39, (byte) 0xC7, (byte) 0x35, (byte) 0x60, (byte) 0xD5, (byte) 0xD4, (byte) 0x3F, (byte) 0x4B, (byte) 0x65, (byte) 0x62, (byte) 0xC2, (byte) 0xEE, (byte) 0xA5, (byte) 0xB1, (byte) 0xD9, (byte) 0x26, (byte) 0xD8, (byte) 0x6B, (byte) 0x51, (byte) 0x10, (byte) 0x8A, (byte) 0x26, (byte) 0x43, (byte) 0xC7, (byte) 0x0F, (byte) 0xB7, (byte) 0x4D, (byte) 0x64, (byte) 0x42, (byte) 0xCE, (byte) 0x3A, (byte) 0x08, (byte) 0x33, (byte) 0x9B, (byte) 0x8F, (byte) 0xD8, (byte) 0xF6, (byte) 0x60, (byte) 0xAE, (byte) 0x88, (byte) 0x12, (byte) 0x9B, (byte) 0x7A, (byte) 0xB8, (byte) 0xC4, (byte) 0x6F, (byte) 0x2F, (byte) 0xA5, (byte) 0x81, (byte) 0x24, (byte) 0x48, (byte) 0x5C, (byte) 0xCC, (byte) 0xB1, (byte) 0xE9, (byte) 0x87, (byte) 0xB0, (byte) 0x5A, (byte) 0x6D, (byte) 0xA6, (byte) 0x5A, (byte) 0x01, (byte) 0x85, (byte) 0x8E, (byte) 0xD3, (byte) 0xF8, (byte) 0x99, (byte) 0x05, (byte) 0x44, (byte) 0x9A, (byte) 0xE4, (byte) 0x2B, (byte) 0xB0, (byte) 0x72, (byte) 0x90, (byte) 0xFC, (byte) 0xB9, (byte) 0x99, (byte) 0x4B, (byte) 0xF2, (byte) 0x2E, (byte) 0x26, (byte) 0x61, (byte) 0x0B, (byte) 0xCA, (byte) 0xBB, (byte) 0x98, (byte) 0x04, (byte) 0x78, (byte) 0x3A, (byte) 0x3B, (byte) 0x95, (byte) 0x87, (byte) 0x91, (byte) 0x7F, (byte) 0x3D, (byte) 0x97, (byte) 0x31, (byte) 0x6E, (byte) 0xDD, (byte) 0xA1, (byte) 0x5C, (byte) 0x5E, (byte) 0x13, (byte) 0xF7, (byte) 0x90, (byte) 0x66, (byte) 0x40, (byte) 0x7B, (byte) 0x55, (byte) 0xA9, (byte) 0x3B, (byte) 0x29, (byte) 0x1B, (byte) 0x68, (byte) 0xA4, (byte) 0xAC, (byte) 0x42, (byte) 0xA9, (byte) 0x8D, (byte) 0x6E, (byte) 0x35, (byte) 0xFE, (byte) 0xD8, (byte) 0x4B, (byte) 0x14, (byte) 0xA7, (byte) 0x92, (byte) 0xD1, (byte) 0x54, (byte) 0xE6, (byte) 0x20, (byte) 0x28, (byte) 0xDD, (byte) 0xAD, (byte) 0x20, (byte) 0xFC, (byte) 0x30, (byte) 0x19, (byte) 0x51, (byte) 0xE5, (byte) 0x92, (byte) 0x4B, (byte) 0xE9, (byte) 0xAD, (byte) 0x62, (byte) 0xFB, (byte) 0x71, (byte) 0x9D, (byte) 0xD9, (byte) 0x4C, (byte) 0xC3, (byte) 0x0C, (byte) 0xAB, (byte) 0x87, (byte) 0x1B, (byte) 0xEC, (byte) 0x43, (byte) 0x77, (byte) 0xA8};

    public static final int SIMPLE1_DECRYPT_KEY = 121;
    public static final long SIMPLE2_DECRYPT_KEY_U32 = 0xE55B4ED1L;
    public static final byte[] SIMPLE2_DECRYPT_KEY = new byte[] {(byte) 0xE5, (byte) 0x5B, (byte) 0x4E, (byte) 0xD1};
    public static final int SIMPLE2_BLOCK_SIZE = 16;

    public static final String SM4_SECRET_2 = "Q0hVTKey$as*1ZFlQCiA";
    public static final String SM4_SECRET_4 = "eb691efea914241317a8";
    public static final String[] SM4_SECRET_NEW = new String[] {"xG2qW5lP7lV2iN5fN5pG", "xT1cJ6dL5wC0kK1rB4dK", "qC4jS5bZ6fL5xE6nD4zA", "gD4jQ2aL3bS3lC3xT0iW", "xU1yQ8wE9zY3gZ3bT5aE", "uQ3cO2dX7xY4xU7gH7iS", "gW1fR0jK6wQ4oN0oK1kZ", "aJ4pV7iZ7pU4wP2aC2cZ", "cX6jT3cM2oT3vK0kJ1qN", "iT2vS0cS6yT6cZ1sE1lO", "hM1pH9iY8wM9hT4lN5uJ", "kG6bC8jK0fL0dE4sH4mL", "dB6lB3vE0eZ8wM8rI0aC", "tP7sP7nI9rA2vQ4cV5yQ", "aT0cL1yN4pT3sZ7eM2vY", "uV6fU8fC9zN3mP5dH8mN", "rT6aQ6oZ1yM0gO5tO1aN", "jU5bH7lQ0fM9hK2kI0o", "iQ0eM0mJ7uT0kV6kL5pY"};

    public static final int EM_SIMPLE1 = 1;
    public static final int EM_SIMPLE2 = 16;
    public static final int EM_SM4_2 = 2;
    public static final int EM_SM4_4 = 4;
    public static final int EM_SM4_NEW_BASE = 31;
    public static final int EM_SM4_NEW_MASK = ~EM_SM4_NEW_BASE;

    public static final int CM_NONE = 0;
    public static final int CM_ZLIB = 1;
    public static final int CM_ZSTD = 6;
    public static final int CM_ZSTD_DICT = 8;
    public static final int CM_MASK = 15;

    private static int[] buildStdToBgmi() {
        int[] reverse = new int[64];
        java.util.Arrays.fill(reverse, -1);
        for (int i = 0; i < BGMI_TO_STD.length; i++) {
            int opcode = BGMI_TO_STD[i];
            if (opcode >= 0 && opcode < reverse.length) reverse[opcode] = i;
        }
        return reverse;
    }
}
