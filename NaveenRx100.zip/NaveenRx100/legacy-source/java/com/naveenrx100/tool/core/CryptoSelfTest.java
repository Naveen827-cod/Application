/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.Arrays;

/** Optional deterministic test vectors for the Batch 4 cryptography layer. */
public final class CryptoSelfTest {
    private CryptoSelfTest() {}
    private static byte[] hex(String s) {
        byte[] b = new byte[s.length()/2];
        for (int i=0;i<b.length;i++) b[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);
        return b;
    }
    private static void require(boolean ok,String name){if(!ok)throw new AssertionError("Crypto self-test failed: "+name);}
    public static String run() throws Exception {
        require(Arrays.equals(SHA1Hasher.hash("abc".getBytes("US-ASCII")),hex("a9993e364706816aba3e25717850c26c9cd0d89d")),"SHA-1 hashlib vector");
        byte[] key=hex("000102030405060708090a0b0c0d0e0f"), plain=hex("101112131415161718191a1b1c1d1e1f");
        SM4Cipher sm4=new SM4Cipher(key); byte[] encrypted=sm4.encryptBlock(plain);
        require(Arrays.equals(encrypted,hex("24e163f31e43eb9374412b0e24529e2e")),"HXE.py custom SM4 vector");
        require(Arrays.equals(sm4.decryptBlock(encrypted),plain),"SM4 round trip");
        require(Arrays.equals(AESCipher.decryptNoPadding(hex("7649abac8119b246cee98e9b12e9197d"),hex("2b7e151628aed2a6abf7158809cf4f3c"),hex("000102030405060708090a0b0c0d0e0f")),hex("6bc1bee22e409f96e93d7e117393172a")),"AES-CBC NIST vector");
        require(Arrays.equals(ZUCCipher.generate(hex("00000000000000000000000000000000"),hex("00000000000000000000000000000000"),16),hex("27bede74018082da87d4e5b69f18bf66")),"ZUC-128 standard vector");
        require(SM4Cipher.sBoxLength()==256&&SM4Cipher.fkLength()==4&&SM4Cipher.ckLength()==32,"SM4 table dimensions");
        return "PASS: SHA-1, AES-CBC, HXE custom SM4, ZUC-128, table dimensions";
    }
}
