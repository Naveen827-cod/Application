/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.Arrays;

/** Lua 5.3/HXE 33-byte header plus the HXE nibble flag byte at offset 33. */
public final class LuaHeader {
    public static final int HEADER_SIZE = 33;
    public static final int NIBBLE_OFFSET = 33;
    private final byte[] raw;
    private final int sizeT;
    private final int nibbleFlag;

    public LuaHeader(byte[] bytes) { this(bytes, bytes != null && bytes.length > NIBBLE_OFFSET ? bytes[NIBBLE_OFFSET] & 0xff : 0); }
    public LuaHeader(byte[] bytes, int nibbleFlag) {
        if (bytes == null || bytes.length < HEADER_SIZE) throw new IllegalArgumentException("Lua header must contain at least 33 bytes");
        if (bytes[0] != 0x1b || bytes[1] != 'L' || bytes[2] != 'u' || bytes[3] != 'a') throw new IllegalArgumentException("Not a Lua bytecode header");
        this.raw = Arrays.copyOf(bytes, HEADER_SIZE);
        int s = raw[13] & 0xff;
        this.sizeT = (s == 4 || s == 8) ? s : 4;
        this.nibbleFlag = (nibbleFlag >= 0 && nibbleFlag <= 2) ? nibbleFlag : 0;
    }
    public int getVersion() { return raw[4] & 0xff; }
    public int getFormat() { return raw[5] & 0xff; }
    public int getIntegerSize() { return raw[12] & 0xff; }
    public int getSizeT() { return sizeT; }
    public int getNibbleFlag() { return nibbleFlag; }
    public byte[] getRawHeader() { return raw.clone(); }
    public byte[] write() { byte[] out = raw.clone(); out[13] = (byte) sizeT; return out; }
    public byte[] writeWithNibbleFlag() { byte[] out = Arrays.copyOf(write(), HEADER_SIZE + 1); out[HEADER_SIZE] = (byte)nibbleFlag; return out; }
    public static LuaHeader parse(byte[] data) { if (data == null || data.length < HEADER_SIZE + 1) throw new IllegalArgumentException("Bytecode is shorter than header plus nibble flag"); return new LuaHeader(data, data[HEADER_SIZE] & 0xff); }
}
