/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** File-entry metadata parsed in HXE.py field order for PAK versions 1-12. */
public final class TencentPakEntry {
    public final byte[] content_hash; public long offset,uncompressed_size,size; public int compression_method; public int unk1; public byte[] unk2; public final List<PakCompressedBlock> compressed_blocks; public int compression_block_size; public boolean encrypted; public int encryption_method,index_new_sep;
    public TencentPakEntry(PakReader reader,int version){
        if(version<1||version>12)throw new IllegalArgumentException("Unsupported PAK version: "+version);
        content_hash=reader.bytes(20);if(version<=1)reader.u8();offset=reader.u8();uncompressed_size=reader.u8();compression_method=(int)(reader.u4()&Constants.CM_MASK);size=reader.u8();
        unk1=version>=5?reader.u1():0;unk2=version>=5?reader.bytes(20):new byte[0];
        if(compression_method!=0&&version>=3){long count=reader.u4();if(count>1_000_000L)throw new IllegalArgumentException("Corrupted PAK: unreasonable block count "+count);compressed_blocks=new ArrayList<>((int)count);for(int i=0;i<count;i++)compressed_blocks.add(new PakCompressedBlock(reader));}else compressed_blocks=new ArrayList<>();
        compression_block_size=version>=4?(int)reader.u4():0;encrypted=version>=4&&reader.u1()==1;encryption_method=version>=12?(int)reader.u4():0;index_new_sep=version>=12?(int)reader.u4():0;
    }
    public TencentPakEntry(byte[] contentHash,long offset,long uncompressedSize,int compressionMethod,long size,List<PakCompressedBlock> blocks,int blockSize,boolean encrypted,int encryptionMethod,int indexNewSep){this.content_hash=contentHash==null?new byte[20]:contentHash.clone();this.offset=offset;this.uncompressed_size=uncompressedSize;this.compression_method=compressionMethod;this.size=size;this.unk1=0;this.unk2=new byte[0];this.compressed_blocks=blocks==null?new ArrayList<PakCompressedBlock>():new ArrayList<>(blocks);this.compression_block_size=blockSize;this.encrypted=encrypted;this.encryption_method=encryptionMethod;this.index_new_sep=indexNewSep;}
    public List<PakCompressedBlock> getCompressedBlocks(){return Collections.unmodifiableList(compressed_blocks);}
}
