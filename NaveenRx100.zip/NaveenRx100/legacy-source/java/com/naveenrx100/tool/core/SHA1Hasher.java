/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** SHA-1 byte hashing compatible with Python hashlib.sha1(data).digest(). */
public final class SHA1Hasher {
    private SHA1Hasher() {}
    public static byte[] hash(byte[] data) {
        if (data == null) throw new IllegalArgumentException("data must not be null");
        try { return MessageDigest.getInstance("SHA-1").digest(data); }
        catch (NoSuchAlgorithmException e) { throw new IllegalStateException("SHA-1 is required by the Java platform", e); }
    }
    public static byte[] sha1(byte[] data) { return hash(data); }
    public static String hex(byte[] data) {
        byte[] digest = hash(data); StringBuilder out = new StringBuilder(digest.length * 2);
        for (byte b : digest) out.append(String.format(java.util.Locale.ROOT, "%02x", b & 0xFF));
        return out.toString();
    }
}
