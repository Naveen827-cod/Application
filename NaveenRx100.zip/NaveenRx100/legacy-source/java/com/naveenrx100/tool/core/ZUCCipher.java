/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.Arrays;
import org.bouncycastle.crypto.engines.Zuc128Engine;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;

/** ZUC-128 keystream generation compatible with gmalg.ZUC(key, iv).generate(). */
public final class ZUCCipher {
    private ZUCCipher() {}
    public static byte[] generate(byte[] key, byte[] iv, int byteCount) {
        if (key == null || key.length != 16) throw new IllegalArgumentException("ZUC-128 key must be 16 bytes");
        if (iv == null || iv.length != 16) throw new IllegalArgumentException("ZUC-128 IV must be 16 bytes");
        if (byteCount < 0) throw new IllegalArgumentException("byteCount must be non-negative");
        Zuc128Engine engine = new Zuc128Engine();
        engine.init(true, new ParametersWithIV(new KeyParameter(key), iv));
        byte[] zeros = new byte[byteCount], output = new byte[byteCount];
        engine.processBytes(zeros, 0, zeros.length, output, 0);
        return output;
    }
    public static byte[] generate(int byteCount) { return generate(Constants.ZUC_KEY, Constants.ZUC_IV, byteCount); }
    /** Returns sixteen 32-bit words, each interpreted big-endian as HXE.py does. */
    public static int[] generateWords(byte[] key, byte[] iv, int wordCount) {
        byte[] bytes = generate(key, iv, Math.multiplyExact(wordCount, 4));
        int[] words = new int[wordCount];
        for (int i=0;i<wordCount;i++) { int p=i*4; words[i]=((bytes[p]&255)<<24)|((bytes[p+1]&255)<<16)|((bytes[p+2]&255)<<8)|(bytes[p+3]&255); }
        return words;
    }
    public static int[] generateWords() { return generateWords(Constants.ZUC_KEY, Constants.ZUC_IV, 16); }
    public static int[] zuc_keystream() { return generateWords(); }
    public static byte[] xor(byte[] data, byte[] keyStream) {
        if (data == null || keyStream == null || keyStream.length == 0) throw new IllegalArgumentException("data and non-empty keystream required");
        byte[] out = new byte[data.length]; for(int i=0;i<data.length;i++) out[i]=(byte)(data[i]^keyStream[i%keyStream.length]); return out;
    }
}
