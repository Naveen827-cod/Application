/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.Arrays;

/** Tencent-specific extension of the PAK footer (versions 1-12). */
public final class TencentPakInfo extends PakInfo {
    public final byte[] unk1,packed_key,packed_iv,packed_index_hash,content_org_hash;
    public final long stem_hash,unk2;
    public TencentPakInfo(byte[] buffer,int[] keystream) {
        super(buffer,keystream);
        int size=memSize(version); if(buffer.length<size)throw new IllegalArgumentException("Corrupted PAK: incomplete Tencent footer for version "+version);
        PakReader r=new PakReader(Arrays.copyOfRange(buffer,buffer.length-size,buffer.length));
        this.unk1=version>=7?xor(r.bytes(32),wordsLe(keystream,7,8)):new byte[0];
        this.packed_key=version>=8?r.bytes(256):new byte[0];
        this.packed_iv=version>=8?r.bytes(256):new byte[0];
        this.packed_index_hash=version>=8?r.bytes(256):new byte[0];
        this.stem_hash=version>=9?(r.u4()^ (keystream[8]&0xffffffffL)):0;
        this.unk2=version>=9?(r.u4()^ (keystream[9]&0xffffffffL)):0;
        this.content_org_hash=version>=12?r.bytes(20):new byte[0];
    }
    public static int memSize(int version){return PakInfo.memSize(version)+(version>=7?32:0)+(version>=8?768:0)+(version>=9?8:0)+(version>=12?20:0);}
    public static int _mem_size(int version){return memSize(version);}
    @Override public byte[] getPackedKey(){return packed_key.clone();} @Override public byte[] getPackedIv(){return packed_iv.clone();}
}
